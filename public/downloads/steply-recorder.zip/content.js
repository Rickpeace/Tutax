"use strict";

// Steply Recorder - Content-Script (laeuft in JEDER http(s)-Seite, deklarativ im
// Manifest registriert, run_at document_start). Standardmaessig PASSIV: es zeichnet
// NUR waehrend einer laufenden Aufnahme Klicks auf.
//
// WARUM DEKLARATIV STATT PROGRAMMATISCHER INJEKTION (v1-Problem):
// v1 injizierte das Script per chrome.scripting nur in den aktiven Tab mit activeTab.
// Das scheiterte auf vielen Seiten und ueberlebte KEINE Navigation - Klicks auf
// Folge-Seiten fehlten. Deklarativ registriert laeuft das Script auf jeder Seite und
// in jeder Folge-Seite innerhalb des Tabs automatisch neu. Damit ueberleben Klicks den
// Seitenwechsel innerhalb des Tabs.
//
// WIE ES WEISS, OB AUFGENOMMEN WIRD:
// Die Seitenleiste (panel.js) schreibt beim Start { rec: { startedAt } } nach
// chrome.storage.local und loescht es beim Stopp. Dieses Content-Script liest den
// Zustand beim Laden UND lauscht auf storage-Aenderungen (chrome.storage.onChanged).
// So braucht es KEINE direkte Nachricht - eine frisch geladene Folge-Seite sieht den
// laufenden Zustand sofort.
//
// UHR-SYNCHRONISATION (bewusst einfach + robust):
// Content-Script und Seitenleiste laufen auf DERSELBEN Maschine und teilen sich damit
// dieselbe Wanduhr (Date.now()). startedAt ist Date.now() aus der Seitenleiste. Fuer
// jeden Klick gilt t = (Date.now() - startedAt) / 1000. Kein Abgleich von
// performance.now()-Zeiturspruengen ueber Kontextgrenzen noetig.

(() => {
  // Doppel-Registrierung vermeiden (z. B. wenn Chrome das Script mehrfach laedt).
  if (window.__steplyRecorderInstalled) return;
  window.__steplyRecorderInstalled = true;

  // Hauptfenster oder iframe? Das Script laeuft (Welle 48) in ALLEN Frames einer Seite. Nur das
  // Hauptfenster (IS_TOP) bedient Pairing/Marker-Nachrichten und Schritte OHNE Frame-Angabe;
  // iframes nehmen auf und bedienen nur Schritte, deren interaction.frame zu ihnen passt.
  let IS_TOP = true;
  try {
    IS_TOP = window.top === window;
  } catch (err) {
    IS_TOP = false;
  }

  // ---- INTERACTION-Vertrag (Welle 48) ---------------------------------------------------
  // Optionales Objekt step.interaction — alles, was ueber „Klick"/„Eingabe" hinausgeht. Reist
  // content.js -> panel.js -> guide-complete -> steps.interaction (jsonb) -> automation_steps
  // .interaction -> Plan -> steply-exec-step / steply-guide-show zurueck an content.js:
  //   enter:   true                           Eingabe per Enter abgeschickt (nur action "type")
  //   variant: "right"|"double"|"drag"|"key"  Rechtsklick / Doppelklick / Ziehen / Tastenkuerzel
  //   key:     "Ctrl+S"                       nur variant "key": Anzeige-Form (Ctrl/Alt/Shift/Meta+Taste)
  //   drop:    {css,text,role}, dropLabel     nur variant "drag": Ablage-Ziel
  //   hover:   {css,text,role}, hoverLabel    vorher mit der Maus ueber dieses Element (Menue)
  //   frame:   {url}                          Schritt liegt in einem iframe (origin+pathname)
  // NIE Feldinhalte. Unbekannte Schluessel verwirft der Server.
  // Selektor-Erweiterung: selector.shadow = [hostCss, …] (Shadow-Host-Pfade aussen -> innen);
  // css/text/role gelten dann im innersten Shadow-Root (Aufloesung: guide-resolve.js).
  // Panel-intern (nicht hochgeladen): step.frameKey — Zufalls-Kennung eines iframe-Schritts, zu
  // der das Hauptfenster per steply-frame-geo die echte Markierungs-Lage nachreicht.
  // Erfassung (Welle 48b): Enter (Feld / contenteditable-Chat), Rechtsklick, Doppelklick (patch),
  // Ziehen (HTML5 + Zeiger, patch), Tastenkuerzel, Hover-Menues (ARIA), iframes, Shadow DOM.

  // ---- Erkennungs-Marker fuer App-Seiten (Welle 25) ------------------------
  // FRUEH (document_start) ein DOM-Attribut setzen, damit App-Seiten erkennen, dass die
  // Extension installiert ist. WICHTIG: Content-Script und Seite laufen in getrennten
  // JS-Welten (isolated world) - window-Variablen dieses Scripts sind fuer Seiten-Skripte
  // UNSICHTBAR. NUR das DOM ist geteilt, also ist ein Attribut der einzig verlaessliche
  // Marker. Wert = die Versionsnummer aus dem Manifest (die App zeigt „Installiert (vX)").
  try {
    const setMarker = () => {
      if (IS_TOP && document.documentElement && chrome.runtime && chrome.runtime.getManifest) {
        document.documentElement.setAttribute(
          "data-steply-recorder",
          chrome.runtime.getManifest().version
        );
      }
    };
    setMarker();
    // Falls documentElement bei document_start noch nicht existiert: beim naechsten Tick.
    if (!document.documentElement) {
      document.addEventListener("readystatechange", setMarker, { once: true });
    }
  } catch (err) {
    /* Marker ist optional - im Zweifel still weiter */
  }

  // ---- Ein-Klick-Pairing (Welle 25) ----------------------------------------
  // Die App-Seite (Einstellungen -> Einbetten) stoesst das Verbinden per window.postMessage
  // an. SICHERHEIT (Origin-Bindung): Wir nehmen die Nachricht NUR an, wenn
  //   - event.source === window   (echtes Seiten-Fenster, kein iframe/fremder Kontext)
  //   - event.origin === location.origin  (kein fremder Absender)
  //   - event.data.__steply === true UND type === "steply-pair"
  //   - token ein plausibler String (Laenge gekappt)
  // Dann reichen wir NUR den Token an background.js weiter - mit appUrl = event.origin
  // (der verifizierten Herkunft, NICHT einem im Payload behaupteten Wert). background.js
  // validiert den Token GEGEN die Ziel-App, BEVOR etwas gespeichert wird. Das Ergebnis
  // (inkl. Kontoname) posten wir an die Seite zurueck -> sie zeigt Erfolg/Fehler an.
  function postPairResult(payload) {
    try {
      window.postMessage(
        Object.assign({ __steply: true, type: "steply-pair-result" }, payload),
        location.origin
      );
    } catch (err) {
      /* egal */
    }
  }
  window.addEventListener("message", (event) => {
    if (!IS_TOP || event.source !== window) return; // App-Seiten-Brücke nur im Hauptfenster
    if (event.origin !== location.origin) return;
    const d = event.data;
    if (!d || d.__steply !== true || d.type !== "steply-pair") return;
    const token = typeof d.token === "string" ? d.token.slice(0, 200).trim() : "";
    if (!token) {
      postPairResult({ ok: false, error: "Kein Verbindungscode übergeben." });
      return;
    }
    try {
      chrome.runtime
        .sendMessage({ type: "steply-pair", token, appUrl: event.origin })
        .then(
          (resp) =>
            postPairResult({
              ok: !!(resp && resp.ok),
              account: (resp && resp.account) || "",
              error: (resp && resp.error) || "",
            }),
          (err) =>
            postPairResult({
              ok: false,
              error: (err && err.message) || "Verbindung fehlgeschlagen.",
            })
        );
    } catch (err) {
      postPairResult({ ok: false, error: "Steply-Erweiterung nicht erreichbar." });
    }
  });

  // ---- Seitenleiste per Klick auf der App-Seite oeffnen (v2.2.1) -------------
  // Die Sofort-Anleitung-Karte im „Neue Anleitung"-Dialog postet {type:"steply-open-panel"}.
  // Gleiche Origin-Bindung wie beim Pairing. background.js ruft chrome.sidePanel.open()
  // SYNCHRON im onMessage-Handler auf - die Klick-Geste der Seite reicht dafuer durch
  // (Chrome >= 116), solange dazwischen nichts awaited wird.
  window.addEventListener("message", (event) => {
    if (!IS_TOP || event.source !== window) return; // App-Seiten-Brücke nur im Hauptfenster
    if (event.origin !== location.origin) return;
    const d = event.data;
    if (!d || d.__steply !== true || d.type !== "steply-open-panel") return;
    try {
      chrome.runtime.sendMessage({ type: "steply-open-panel" });
    } catch (err) {
      /* Extension nicht erreichbar - Karte zeigt den manuellen Weg als Fallback */
    }
  });

  // ---- Aufnahme-Anker: „Ab hier mit Extension aufnehmen" (Welle 27) ----------
  // Ein Einfügepunkt im Steply-Builder postet {type:"steply-record-into", target, label}.
  // GLEICHE Origin-Bindung wie beim Pairing/Panel-Oeffnen. Wir reichen NUR ein sauberes,
  // laengen-gekapptes Ziel an background.js weiter (dort: Seitenleiste synchron oeffnen +
  // pendingTarget speichern). Die Herkunft (origin) bestimmt background aus dem Sender,
  // nicht aus dem Payload. Der target-Inhalt (tutorialId/anchor) wird ausserdem serverseitig
  // in guide-complete streng geprueft (Konto-Eigentum, Entwurf, Anker) - hier nur Hygiene.
  function cleanId(v) {
    return typeof v === "string" ? v.slice(0, 100).trim() : "";
  }
  window.addEventListener("message", (event) => {
    if (!IS_TOP || event.source !== window) return; // App-Seiten-Brücke nur im Hauptfenster
    if (event.origin !== location.origin) return;
    const d = event.data;
    if (!d || d.__steply !== true || d.type !== "steply-record-into") return;
    const t = d.target && typeof d.target === "object" ? d.target : null;
    const a = t && t.anchor && typeof t.anchor === "object" ? t.anchor : null;
    if (!t || !a) return;
    const tutorialId = cleanId(t.tutorialId);
    if (!tutorialId) return;
    // Genau EIN Anker-Feld durchreichen (afterStepId ODER branchId).
    let anchor = null;
    if (cleanId(a.afterStepId)) anchor = { afterStepId: cleanId(a.afterStepId) };
    else if (cleanId(a.branchId)) anchor = { branchId: cleanId(a.branchId) };
    if (!anchor) return;
    const label = typeof d.label === "string" ? d.label.slice(0, 160).trim() : "";
    try {
      chrome.runtime.sendMessage({
        type: "steply-record-into",
        target: { tutorialId, anchor },
        label,
      });
    } catch (err) {
      /* Extension nicht erreichbar - der Builder zeigt den manuellen Weg als Fallback */
    }
  });

  let recording = false;
  let startEpoch = 0;
  // Modus der laufenden Aufnahme: "video" (Screencast + Klick-Zeitstempel, Bestand) oder
  // "guide" (Sofort-Anleitung: pro Klick ein Screenshot + Element-Box, KEIN Video).
  let mode = "video";
  // guide-Modus: aktuell fokussiertes editierbares Feld (fuer die blur-basierte Eingabe-
  // Erkennung). startValue bleibt LOKAL (Vergleich), wird NIE ans Panel gesendet.
  let focusedEditable = null; // { el, kind, startValue, settled }

  function truncate(text, max) {
    if (!text) return "";
    const clean = String(text).replace(/\s+/g, " ").trim();
    return clean.length > max ? clean.slice(0, max - 1) + "…" : clean;
  }

  // ---- Shadow DOM (Welle 48): Web-Komponenten (Salesforce, Microsoft, SAP UI5 …) ----------
  // Listener an `document` sehen bei OFFENEN Shadow-Roots nur den Host als event.target. Das
  // echte Ziel ist composedPath()[0]. Geschlossene Roots bleiben unsichtbar (dann eben der Host).
  function realTarget(event) {
    let t = null;
    try {
      const path = event.composedPath ? event.composedPath() : null;
      t = path && path.length ? path[0] : null;
    } catch (err) {
      t = null;
    }
    if (!t) t = event.target;
    if (t && t.nodeType === 3) t = t.parentElement || flatParent(t);
    return t && t.nodeType === 1 ? t : event.target;
  }

  // Eltern im „flachen" Baum: zugewiesener <slot> > DOM-Eltern > Shadow-Host. So gehen
  // closest-artige Suchen ueber Shadow-Grenzen nach oben (Text im Slot -> Button im Root).
  function flatParent(n) {
    if (!n) return null;
    try {
      if (n.assignedSlot) return n.assignedSlot;
    } catch (err) {
      /* egal */
    }
    if (n.parentElement) return n.parentElement;
    const p = n.parentNode;
    return p && p.nodeType === 11 && p.host ? p.host : null;
  }

  // closest() ueber Shadow-Grenzen hinweg (flacher Baum).
  function closestDeep(el, sel) {
    let n = el;
    for (let i = 0; n && i < 400; i++) {
      if (n.nodeType === 1) {
        try {
          if (n.matches(sel)) return n;
        } catch (err) {
          return null;
        }
      }
      n = flatParent(n);
    }
    return null;
  }

  // Der Shadow-Root, in dem el liegt (null im normalen Dokument).
  function shadowRootOf(el) {
    try {
      const r = el && el.getRootNode ? el.getRootNode() : null;
      return r && r.nodeType === 11 && r.host ? r : null;
    } catch (err) {
      return null;
    }
  }
  // Such-Scope fuer id-/label-Referenzen: der eigene Root (ids gelten nur darin).
  function scopeOf(el) {
    return shadowRootOf(el) || document;
  }

  // `change` ist NICHT composed — Aenderungen in Shadow-Roots erreichen den document-Listener
  // nie. Fokuswechsel INNERHALB eines Roots (Feld -> Feld im selben Formular) ebenfalls nicht
  // (nach dem Retargeting waeren target und relatedTarget beide der Host -> Weitergabe stoppt).
  // Darum je beruehrtem Root EINMAL dieselben Listener direkt am Root anmelden. Kreuzt ein
  // Fokuswechsel die Grenze, feuern Root- UND document-Listener — die Handler sind dagegen
  // idempotent (focusout raeumt focusedEditable beim ersten Aufruf ab).
  const watchedRoots = new WeakSet();
  function watchShadowRoots(el) {
    let r = shadowRootOf(el);
    for (let i = 0; r && i < 10; i++) {
      if (!watchedRoots.has(r)) {
        watchedRoots.add(r);
        try {
          r.addEventListener("change", onChange, true);
          r.addEventListener("focusin", onFocusIn, true);
          r.addEventListener("focusout", onFocusOut, true);
        } catch (err) {
          /* egal */
        }
      }
      r = shadowRootOf(r.host);
    }
  }

  // Fokussiertes Element auch in (offenen) Shadow-Roots.
  function deepActiveElement() {
    let a = document.activeElement;
    for (let i = 0; a && a.shadowRoot && a.shadowRoot.activeElement && i < 10; i++) {
      a = a.shadowRoot.activeElement;
    }
    return a;
  }

  // Sichtbarer Text im flachen Baum (Slots aufgeloest). innerText eines Elements IM Shadow-Root
  // enthaelt den per <slot> projizierten Light-DOM-Text NICHT (<button><slot></slot></button>
  // -> ""). Kurz gekappt; nur fuer Labels.
  function flatText(node, depth) {
    if (!node || depth > 12) return "";
    if (node.nodeType === 3) return node.nodeValue || "";
    if (node.nodeType !== 1 && node.nodeType !== 11) return "";
    if (node.nodeType === 1) {
      const tag = node.tagName;
      if (tag === "STYLE" || tag === "SCRIPT" || tag === "TEMPLATE" || tag === "NOSCRIPT") return "";
      try {
        const cs = getComputedStyle(node);
        if (cs && (cs.display === "none" || cs.visibility === "hidden")) return "";
      } catch (err) {
        /* egal */
      }
      if (tag === "SLOT") {
        let assigned = [];
        try {
          assigned = node.assignedNodes({ flatten: true });
        } catch (err) {
          assigned = [];
        }
        if (assigned.length) {
          let s = "";
          for (const a of assigned) s += " " + flatText(a, depth + 1);
          return s;
        }
      }
    }
    let out = "";
    const kids = node.nodeType === 1 && node.shadowRoot ? node.shadowRoot.childNodes : node.childNodes;
    for (const k of kids) {
      out += " " + flatText(k, depth + 1);
      if (out.length > 240) break;
    }
    return out;
  }

  // Interaktive Elemente (fuer Klick-Aufloesung UND Dead-Click-Filter). Deckt neben den
  // nativen Widgets auch ARIA-Rollen ab (Checkbox/Switch/Slider/Tab/Option/Combobox).
  const INTERACTIVE_SELECTOR =
    'button, a, [role="button"], [role="link"], [role="menuitem"], [role="menuitemcheckbox"], ' +
    '[role="menuitemradio"], [role="tab"], [role="option"], [role="checkbox"], [role="radio"], ' +
    '[role="switch"], [role="slider"], [role="combobox"], input, textarea, select, summary, ' +
    "label, [onclick]";

  // Das "sinnvolle" Element fuer einen Klick (fuer Label UND Bounding-Box): das naechste
  // interaktive Element in der Ahnenkette, sonst das Ziel selbst.
  function clickableFor(target) {
    if (!target || target.nodeType !== 1) return null;
    const clickable = closestDeep(target, INTERACTIVE_SELECTOR);
    return clickable || target;
  }

  // Wie clickableFor, aber STRENG: null statt Fallback, wenn nichts Interaktives da ist
  // (Dead-Click-Filter der Sofort-Anleitung — Richards Fall: Klick auf eine passive Karte
  // markierte die ganze Karte und nahm ihren kompletten Text als Titel). Zusaetzlich:
  // contenteditable/tabindex>=0 in der Ahnenkette und die cursor:pointer-Heuristik fuer
  // klickbare DIVs ohne Rolle (onclick am Rahmenwerk statt im DOM-Attribut). Bei pointer
  // nehmen wir das AEUSSERSTE Element mit pointer als Widget-Grenze (die ganze Karte,
  // nicht der innere Span).
  function interactiveFor(target) {
    if (!target || target.nodeType !== 1) return null;
    // Ueber Shadow-Grenzen/Slots hinweg (closestDeep/flatParent), Welle 48.
    const hit = closestDeep(target, INTERACTIVE_SELECTOR);
    if (hit) return hit;
    let n = target;
    for (let i = 0; n && n.nodeType === 1 && i < 8; i++) {
      if (n.isContentEditable === true) return n;
      const ti = n.getAttribute && n.getAttribute("tabindex");
      if (ti != null && parseInt(ti, 10) >= 0) return n;
      n = flatParent(n);
    }
    let cur = null;
    try {
      if (getComputedStyle(target).cursor === "pointer") cur = target;
    } catch (err) {
      cur = null;
    }
    if (cur) {
      let p = flatParent(cur);
      let guard = 0;
      while (p && p !== document.body && p !== document.documentElement && guard < 8) {
        let c = "";
        try {
          c = getComputedStyle(p).cursor;
        } catch (err) {
          c = "";
        }
        if (c !== "pointer") break;
        cur = p;
        p = flatParent(p);
        guard++;
      }
      return cur;
    }
    return null;
  }

  // Whitespace kollabieren und an einer Wortgrenze auf max Zeichen kappen (60 fuer Labels).
  function clampLabel(text, max) {
    if (!text) return "";
    const clean = String(text).replace(/\s+/g, " ").trim();
    if (clean.length <= max) return clean;
    let cut = clean.slice(0, max - 1);
    const sp = cut.lastIndexOf(" ");
    if (sp >= Math.floor(max * 0.5)) cut = cut.slice(0, sp);
    return cut.replace(/[\s.,;:]+$/, "") + "…";
  }

  // CSS-Sonderzeichen fuer #id / Attribut-Selektoren maskieren.
  function cssEscape(s) {
    try {
      if (window.CSS && CSS.escape) return CSS.escape(String(s));
    } catch (err) {
      /* fallthrough */
    }
    return String(s).replace(/[^a-zA-Z0-9_-]/g, "\\$&");
  }
  function cssEscapeAttr(v) {
    return String(v).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
  }

  // RETTUNGSNETZ: Sieht der Kandidat nach Code/CSS aus (styled-components legt CSS-Text in
  // <style>-Kinder, der frueher per textContent ins Label lief - „asdasda.MagqMc{...}")?
  // Dann verwerfen, damit die naechste Prioritaetsstufe greift.
  function looksLikeCode(s) {
    if (!s) return false;
    const t = String(s);
    if (t.indexOf("{") >= 0 || t.indexOf("}") >= 0) return true;
    const semis = (t.match(/;/g) || []).length;
    if (semis > 3) return true;
    if (/\.[A-Za-z][\w-]*\s*\{/.test(t)) return true; // .klasse { ... }
    if (/^\s*\.[A-Za-z][\w-]*(\s+\.|\s*[{,])/.test(t)) return true; // .A .B / .A{ / .A,
    if (/^\s*\.[A-Za-z0-9_-]*[A-Z][A-Za-z0-9_-]*\s/.test(t)) return true; // .CamelHash <space>
    return false;
  }

  // Sichtbaren Text ueber sichtbare Textknoten sammeln - OHNE <style>/<script>/<template>/
  // <noscript> und ohne display:none/visibility:hidden. Ergaenzt innerText fuer den Fall,
  // dass der pointerdown-Moment ausgeblendete Knoten hat.
  function textFromWalker(root) {
    let out = "";
    try {
      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          const p = node.parentElement;
          if (!p) return NodeFilter.FILTER_REJECT;
          const tag = p.tagName;
          if (tag === "STYLE" || tag === "SCRIPT" || tag === "TEMPLATE" || tag === "NOSCRIPT") {
            return NodeFilter.FILTER_REJECT;
          }
          if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
          try {
            const cs = getComputedStyle(p);
            if (cs && (cs.display === "none" || cs.visibility === "hidden")) {
              return NodeFilter.FILTER_REJECT;
            }
          } catch (err) {
            /* getComputedStyle kann werfen -> Knoten zulassen */
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      while (walker.nextNode()) {
        out += walker.currentNode.nodeValue + " ";
        if (out.length > 240) break;
      }
    } catch (err) {
      out = "";
    }
    return out.replace(/\s+/g, " ").trim();
  }

  // Kurzer sichtbarer Text eines Elements (leer, wenn er nach Code aussieht). innerText
  // ignoriert <style>/<script> bereits; der Walker faengt Rest-Faelle ab.
  function visibleText(el) {
    if (!el || el.nodeType !== 1) return "";
    let txt = "";
    try {
      txt = el.innerText || "";
    } catch (err) {
      txt = "";
    }
    txt = txt.replace(/\s+/g, " ").trim();
    // Shadow DOM (Welle 48): innerText kennt projizierten Slot-Text nicht -> flacher Baum.
    if (shadowRootOf(el) || el.shadowRoot) {
      const flat = flatText(el, 0).replace(/\s+/g, " ").trim();
      if (flat && flat.length > txt.length && !looksLikeCode(flat)) return flat;
    }
    if (txt && !looksLikeCode(txt)) return txt;
    const walked = textFromWalker(el);
    if (walked && !looksLikeCode(walked)) return walked;
    return "";
  }

  // aria-label / aria-labelledby (aufgeloest) -> Text.
  function ariaLabelText(el) {
    if (!el || !el.getAttribute) return "";
    const aria = el.getAttribute("aria-label");
    if (aria && aria.trim()) return aria.trim();
    const labelledby = el.getAttribute("aria-labelledby");
    if (labelledby) {
      let acc = "";
      const scope = scopeOf(el);
      for (const id of labelledby.split(/\s+/)) {
        const ref = id && scope.getElementById && scope.getElementById(id);
        if (ref) {
          const t = visibleText(ref);
          if (t) acc += (acc ? " " : "") + t;
        }
      }
      if (acc) return acc;
    }
    return "";
  }

  // Text des zugehoerigen <label> (el.labels deckt for=id UND umschliessend ab; plus
  // Fallbacks fuer Elemente ohne .labels wie contenteditable).
  function associatedLabelText(el) {
    if (!el) return "";
    try {
      if (el.labels && el.labels.length) {
        for (const l of el.labels) {
          const t = visibleText(l);
          if (t) return t;
        }
      }
    } catch (err) {
      /* egal */
    }
    if (el.id) {
      try {
        const lbls = scopeOf(el).querySelectorAll('label[for="' + cssEscapeAttr(el.id) + '"]');
        for (const l of lbls) {
          const t = visibleText(l);
          if (t) return t;
        }
      } catch (err) {
        /* ungueltige id -> ignorieren */
      }
    }
    const wrap = el.closest ? el.closest("label") : null;
    if (wrap) {
      const t = visibleText(wrap);
      if (t) return t;
    }
    return "";
  }

  // Ist das Element ein <label>, die zugehoerige Kontrolle liefern (fuer Editierbarkeit +
  // Eingabe-Erkennung); sonst das Element selbst.
  function controlForLabel(el) {
    if (!el || el.nodeType !== 1) return el;
    if ((el.tagName || "").toLowerCase() !== "label") return el;
    try {
      if (el.control) return el.control;
    } catch (err) {
      /* egal */
    }
    const forId = el.getAttribute && el.getAttribute("for");
    if (forId) {
      const scope = scopeOf(el);
      const byId = scope.getElementById ? scope.getElementById(forId) : null;
      if (byId) return byId;
    }
    const inner =
      el.querySelector &&
      el.querySelector("input, textarea, select, [contenteditable=''], [contenteditable='true']");
    return inner || el;
  }

  // Editierbarkeit einer (bereits aufgeloesten) Kontrolle bewerten. Editierbar sind
  // textartige input/textarea/select, contenteditable und role=textbox/searchbox/combobox.
  // kind steuert Label- und Snapshot-Logik.
  function editableInfo(el) {
    if (!el || el.nodeType !== 1) return { editable: false, control: el, kind: "" };
    const tag = (el.tagName || "").toLowerCase();
    const type = ((el.getAttribute && el.getAttribute("type")) || el.type || "text").toLowerCase();
    const role = ((el.getAttribute && el.getAttribute("role")) || "").toLowerCase();
    if (tag === "textarea") return { editable: true, control: el, kind: "text" };
    if (tag === "select") return { editable: true, control: el, kind: "select" };
    if (tag === "input") {
      if (/^(button|submit|checkbox|radio|reset|file|image|range|color|hidden)$/.test(type)) {
        return { editable: false, control: el, kind: "" };
      }
      return { editable: true, control: el, kind: type === "password" ? "password" : "text" };
    }
    if (el.isContentEditable === true) return { editable: true, control: el, kind: "rich" };
    if (role === "textbox" || role === "searchbox" || role === "combobox") {
      return { editable: true, control: el, kind: "rich" };
    }
    return { editable: false, control: el, kind: "" };
  }

  // Sichtbare Feldueberschrift in der Naehe finden - das haeufigste Muster OHNE echte
  // <label>-Verknuepfung: <div>Telefon</div><input placeholder="+49 ...">. Wir gehen bis
  // zu 3 Ebenen nach oben und pruefen je Ebene die bis zu 2 unmittelbar vorangehenden
  // Geschwister. Bewusst konservativ: kurzer (<=40), code-freier Text; Geschwister, die
  // selbst Eingabefelder/Buttons enthalten (Formular-Grids), werden uebersprungen.
  function nearbyCaptionText(control) {
    let node = control;
    for (let depth = 0; depth < 3 && node && node !== document.body; depth++) {
      let sib = node.previousElementSibling;
      let hops = 0;
      while (sib && hops < 2) {
        let skip = false;
        try {
          // Interaktive Geschwister (Button/Link/Feld) sind NIE die Ueberschrift dieses
          // Feldes; Container MIT Feldern (Formular-Grids) ebenfalls ueberspringen.
          skip = !!(
            sib.matches &&
            sib.matches("input, textarea, select, button, a, [role='button'], [role='link']")
          );
          if (!skip) {
            skip = !!(
              sib.querySelector && sib.querySelector("input, textarea, select, button")
            );
          }
        } catch (err) {
          skip = true; // im Zweifel ueberspringen
        }
        if (!skip) {
          const t = visibleText(sib);
          if (t && t.length <= 40 && !looksLikeCode(t)) return t;
        }
        sib = sib.previousElementSibling;
        hops++;
      }
      node = node.parentElement;
    }
    return "";
  }

  // Label fuer ein editierbares Feld. DATENSCHUTZ: NIE der getippte Wert (el.value) - bei
  // type=password gilt das erst recht (nichts Feldinhaltliches). Kette: <label> > aria >
  // (select: gewaehlte Option) > sichtbare Feldueberschrift daneben > placeholder > name
  // > title. (Placeholder erst NACH der Ueberschrift: "Telefon" schlaegt "+49 ...".)
  function labelForEditable(control, kind) {
    const lbl = associatedLabelText(control);
    if (lbl && !looksLikeCode(lbl)) return clampLabel(lbl, 60);
    const aria = ariaLabelText(control);
    if (aria && !looksLikeCode(aria)) return clampLabel(aria, 60);
    if (kind === "select") {
      try {
        const opt =
          control.selectedIndex != null && control.selectedIndex >= 0
            ? control.options[control.selectedIndex]
            : null;
        const t = opt && (opt.textContent || opt.label);
        if (t && t.trim()) return clampLabel(t, 60);
      } catch (err) {
        /* egal */
      }
    }
    const cap = nearbyCaptionText(control);
    if (cap) return clampLabel(cap, 60);
    const ph = control.getAttribute && control.getAttribute("placeholder");
    if (ph && ph.trim() && !looksLikeCode(ph)) return clampLabel(ph, 60);
    const nm = control.getAttribute && control.getAttribute("name");
    if (nm && nm.trim()) return clampLabel(nm, 60);
    const ti = control.getAttribute && control.getAttribute("title");
    if (ti && ti.trim() && !looksLikeCode(ti)) return clampLabel(ti, 60);
    return "";
  }

  // Grosse Link-Kacheln (YouTube & Co.): aria-label/sichtbarer Text der GANZEN Kachel
  // enthaelt oft Titel + Metadaten ("... 19 minutes"). Steckt im Element eine echte
  // Ueberschrift, ist DEREN Text das sauberere Label.
  function headingText(el) {
    try {
      const h =
        el.querySelector &&
        el.querySelector('h1, h2, h3, h4, h5, h6, [role="heading"]');
      if (!h) return "";
      const t = visibleText(h);
      return t && t.length <= 80 ? t : "";
    } catch (err) {
      return "";
    }
  }

  // Label fuer ein nicht editierbares Klick-Ziel. Kette: aria > sichtbarer Text >
  // zugehoeriges <label> (Checkbox/Radio/Slider haben selbst keinen Text!) > alt/title >
  // Feldueberschrift daneben > (nur Button-artige input) value > Tag.
  // KEIN value fuer Textfelder (Datenschutz). Ist der Normalweg LANG (>60, Kachel mit
  // Metadaten), gewinnt eine enthaltene Ueberschrift.
  function clickLabel(el) {
    const aria = ariaLabelText(el);
    if (aria && !looksLikeCode(aria)) {
      if (aria.trim().length > 60) {
        const h = headingText(el);
        if (h && !looksLikeCode(h)) return clampLabel(h, 60);
      }
      return clampLabel(aria, 60);
    }
    const text = visibleText(el);
    if (text) {
      if (text.length > 60) {
        const h = headingText(el);
        if (h && !looksLikeCode(h)) return clampLabel(h, 60);
      }
      return clampLabel(text, 60);
    }
    const assoc = associatedLabelText(el);
    if (assoc && !looksLikeCode(assoc)) return clampLabel(assoc, 60);
    const alt = el.getAttribute && (el.getAttribute("alt") || el.getAttribute("title"));
    if (alt && alt.trim() && !looksLikeCode(alt)) return clampLabel(alt, 60);
    const cap = nearbyCaptionText(el);
    if (cap) return clampLabel(cap, 60);
    const tag = (el.tagName || "").toLowerCase();
    const type = ((el.getAttribute && el.getAttribute("type")) || "").toLowerCase();
    if (tag === "input" && /^(button|submit|reset)$/.test(type) && el.value && String(el.value).trim()) {
      return clampLabel(el.value, 60); // Button-Caption (keine getippte Eingabe)
    }
    return clampLabel(tag, 60);
  }

  // Kuerzester sinnvoller Text fuer das geklickte/verlassene Element (editierbar vs. Klick).
  function labelFor(target) {
    if (!target || target.nodeType !== 1) return "";
    const clickable = clickableFor(target) || target;
    const info = editableInfo(controlForLabel(clickable));
    if (info.editable) {
      const l = labelForEditable(info.control, info.kind);
      if (l) return l;
      return clampLabel((info.control.tagName || "feld").toLowerCase(), 60);
    }
    return clickLabel(clickable);
  }

  // ---- Selektor-Vorbau (Welle 24): robuster { css, text, role } je Schritt. ----
  // Wird serverseitig streng validiert und in steps.selector gespeichert; noch NIRGENDS
  // gelesen (Vorbau fuer Live-Fuehrung). KEINE generierten Klassennamen (sc-/css-/Hashes) -
  // wir bauen den css-Pfad bewusst OHNE Klassen (id > data-testid > name/aria-label > nth).
  // Flüchtige-ID-Prüfung (Welle 33, Fix 5): dieselbe Liste wie im Resolver (guide-resolve.js
  // wird VOR content.js injiziert -> globaler Namespace steht bereit). Fehlt sie ausnahmsweise,
  // greifen die lokalen Muster in isStableId weiter.
  function isVolatileIdShared(id) {
    var R = globalThis.SteplyGuideResolve;
    return !!(R && typeof R.isVolatileId === "function" && R.isVolatileId(id));
  }
  function isStableId(id) {
    if (!id || typeof id !== "string") return false;
    if (id.length > 64) return false;
    if (isVolatileIdShared(id)) return false; // Base UI / Radix / useId & Co. -> nie als Anker
    if (id.indexOf(":") >= 0) return false; // React useId ":r5:" u. ae.
    if (/^\d+$/.test(id)) return false; // rein numerisch
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-/i.test(id)) return false; // UUID-artig
    if (/^(radix|headlessui|mui|react-aria|aria)-/i.test(id)) return false; // Framework-generiert
    if (/^[A-Za-z]+[-_][0-9a-f]{6,}$/i.test(id)) return false; // Praefix + Hash
    return true;
  }
  // scope: document oder der Shadow-Root des Elements (Eindeutigkeit gilt im eigenen Root).
  function isUniqueIn(sel, scope) {
    try {
      return (scope || document).querySelectorAll(sel).length === 1;
    } catch (err) {
      return false;
    }
  }
  function nthOfTypePath(el) {
    const parts = [];
    let node = el;
    let depth = 0;
    while (node && node.nodeType === 1 && depth < 5) {
      const tag = node.tagName.toLowerCase();
      if (node.id && isStableId(node.id)) {
        parts.unshift("#" + cssEscape(node.id));
        break; // stabile id ist ein guter Anker -> Pfad hier verankern
      }
      let seg = tag;
      // Oberstes Element eines Shadow-Roots: Geschwister sind die Kinder des Roots.
      const parent =
        node.parentElement ||
        (node.parentNode && node.parentNode.nodeType === 11 ? node.parentNode : null);
      if (parent) {
        const same = Array.prototype.filter.call(parent.children, (c) => c.tagName === node.tagName);
        if (same.length > 1) seg += ":nth-of-type(" + (same.indexOf(node) + 1) + ")";
      }
      parts.unshift(seg);
      if (tag === "html" || tag === "body") break;
      node = node.parentElement;
      depth++;
    }
    return parts.join(" > ");
  }
  function cssPathFor(el) {
    if (!el || el.nodeType !== 1) return "";
    const tag = el.tagName.toLowerCase();
    const scope = scopeOf(el); // Shadow-Root des Elements oder document
    const isUnique = (sel) => isUniqueIn(sel, scope);
    const cap = (s) => (s && s.length <= 400 ? s : "");
    if (el.id && isStableId(el.id)) {
      const sel = "#" + cssEscape(el.id);
      if (isUnique(sel)) return cap(sel);
    }
    const attr = (name) => {
      const v = el.getAttribute && el.getAttribute(name);
      return v && v.length <= 100 ? v : "";
    };
    const testid = attr("data-testid");
    if (testid) {
      let sel = tag + '[data-testid="' + cssEscapeAttr(testid) + '"]';
      if (isUnique(sel)) return cap(sel);
      sel = '[data-testid="' + cssEscapeAttr(testid) + '"]';
      if (isUnique(sel)) return cap(sel);
    }
    const name = attr("name");
    if (name) {
      const sel = tag + '[name="' + cssEscapeAttr(name) + '"]';
      if (isUnique(sel)) return cap(sel);
    }
    const aria = attr("aria-label");
    if (aria) {
      const sel = tag + '[aria-label="' + cssEscapeAttr(aria) + '"]';
      if (isUnique(sel)) return cap(sel);
    }
    return cap(nthOfTypePath(el));
  }
  function roleFor(el) {
    const explicit = el.getAttribute && el.getAttribute("role");
    if (explicit && explicit.trim()) return explicit.trim().toLowerCase();
    const tag = (el.tagName || "").toLowerCase();
    const type = ((el.getAttribute && el.getAttribute("type")) || "").toLowerCase();
    if (tag === "a" && el.hasAttribute && el.hasAttribute("href")) return "link";
    if (tag === "button") return "button";
    if (tag === "select") return "combobox";
    if (tag === "textarea") return "textbox";
    if (tag === "input") {
      if (/^(button|submit|reset|image)$/.test(type)) return "button";
      if (type === "checkbox") return "checkbox";
      if (type === "radio") return "radio";
      if (type === "range") return "slider";
      if (type === "search") return "searchbox";
      return "textbox";
    }
    if (/^h[1-6]$/.test(tag)) return "heading";
    if (tag === "img") return "img";
    if (tag === "nav") return "navigation";
    return "";
  }
  // Shadow-Host-Pfade von aussen nach innen (Vertrag: selector.shadow). Jeder Pfad ist in
  // SEINEM Root eindeutig gebaut (cssPathFor nutzt scopeOf). null, wenn ein Host keinen Pfad
  // bekommt oder die Tiefe die Server-Kappe (5) sprengt — dann ist css unbrauchbar.
  const SHADOW_DEPTH_MAX = 5;
  function shadowHostPath(el) {
    const hosts = [];
    let r = shadowRootOf(el);
    while (r) {
      if (hosts.length >= SHADOW_DEPTH_MAX) return null;
      const hp = cssPathFor(r.host);
      if (!hp) return null;
      hosts.unshift(hp);
      r = shadowRootOf(r.host);
    }
    return hosts;
  }
  function selectorFor(el) {
    if (!el || el.nodeType !== 1) return undefined;
    const out = {};
    // Shadow DOM (Welle 48): css gilt dann relativ zum innersten Root, shadow = Host-Kette.
    const inShadow = !!shadowRootOf(el);
    const hosts = inShadow ? shadowHostPath(el) : null;
    const css = !inShadow || hosts ? cssPathFor(el) : "";
    if (css) out.css = css;
    if (css && hosts && hosts.length) out.shadow = hosts;
    // Text-Gegenprobe fuer die Live-Fuehrung: Eingabefelder (input/textarea/select/
    // contenteditable) haben KEINEN sichtbaren textContent — als `text` daher das zugehoerige
    // LABEL erfassen (dieselbe Kette wie labelFor: <label>/aria/Ueberschrift/placeholder/name).
    // So findet guide-resolve.js das Feld ueber label/placeholder/aria wieder, statt am leeren
    // textContent zu scheitern (Richards Bug: „Tragen Sie … ein" wurde nicht markiert).
    const editable = editableInfo(controlForLabel(el));
    const rawText = editable.editable
      ? labelForEditable(editable.control, editable.kind)
      : visibleText(el);
    const text = clampLabel(rawText || "", 80);
    if (text) out.text = text;
    const role = roleFor(el).slice(0, 40);
    if (role) out.role = role;
    return out.css || out.text || out.role ? out : undefined;
  }

  // Lokaler Snapshot eines Feldwerts NUR zum Vergleich (bleibt IM Content-Script; wird NIE
  // ans Panel gesendet). Bei rich/contenteditable nur die Textlaenge (kein Inhalt).
  function fieldSnapshot(el, kind) {
    try {
      if (kind === "rich") return "len:" + ((el.textContent || "").length);
      return String(el.value == null ? "" : el.value);
    } catch (err) {
      return "";
    }
  }

  function onClick(event) {
    // Nur im Video-Modus Klick-Zeitstempel senden (im guide-Modus laeuft die Erfassung
    // ueber pointerdown, s. u.).
    if (!recording || mode !== "video") return;
    // Video-Modus: Klick-Koordinaten gelten fuer das Hauptfenster. In iframes (all_frames,
    // Welle 48) waeren sie relativ zum iframe -> dort wie frueher (kein Script) nichts senden.
    if (!IS_TOP) return;

    const w = window.innerWidth || document.documentElement.clientWidth || 1;
    const h = window.innerHeight || document.documentElement.clientHeight || 1;

    // clientX/Y ist relativ zum sichtbaren Fenster - passt zum aufgenommenen
    // Tab-Inhalt. Werte defensiv auf 0..1 klemmen.
    const x = Math.min(1, Math.max(0, event.clientX / w));
    const y = Math.min(1, Math.max(0, event.clientY / h));
    const t = Math.max(0, (Date.now() - startEpoch) / 1000);

    const click = {
      t: Math.round(t * 1000) / 1000,
      x: Math.round(x * 10000) / 10000,
      y: Math.round(y * 10000) / 10000,
      label: labelFor(event.target),
    };

    try {
      chrome.runtime.sendMessage({ type: "steply-click", click });
    } catch (err) {
      // Extension-Kontext evtl. weg (Reload) -> als beendet betrachten.
      recording = false;
    }
  }

  // Capture-Phase: Klick wird erfasst, auch wenn die Seite stopPropagation nutzt.
  document.addEventListener("click", onClick, true);

  // Rect (0..1, TANGO-Trick fuer pixelgenaue Markierung) + Pixel-Lage eines Elements.
  // Pixel-Box (Viewport dieses Fensters) -> 0..1 normiert, geklemmt (Hauptfenster; die
  // iframe-Umrechnung nutzt dieselbe Normierung, s. onFrameGeo).
  function normRect(left, top, width, height) {
    const w = window.innerWidth || document.documentElement.clientWidth || 1;
    const h = window.innerHeight || document.documentElement.clientHeight || 1;
    const clamp = (n) => Math.min(1, Math.max(0, n));
    const round = (n) => Math.round(n * 10000) / 10000;
    const rect = {
      x: round(clamp(left / w)),
      y: round(clamp(top / h)),
      w: round(clamp(width / w)),
      h: round(clamp(height / h)),
    };
    if (rect.x + rect.w > 1) rect.w = round(1 - rect.x);
    if (rect.y + rect.h > 1) rect.h = round(1 - rect.y);
    return rect;
  }
  function rectOf(el) {
    const px = { left: 0, top: 0, width: 0, height: 0, cx: 0, cy: 0 };
    let rect = { x: 0, y: 0, w: 0, h: 0 };
    try {
      const r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null;
      if (r && r.width >= 0 && r.height >= 0) {
        px.left = r.left; px.top = r.top; px.width = r.width; px.height = r.height;
        px.cx = r.left + r.width / 2; px.cy = r.top + r.height / 2;
        rect = normRect(r.left, r.top, r.width, r.height);
      }
    } catch (err) {
      // Bounding-Box nicht ermittelbar -> leeres Rechteck (Markierung entfaellt still).
    }
    return { rect, px };
  }

  // ---- Auto-Schwaerzung (Welle 28): Rechtecke sichtbarer SENSIBLER Felder sammeln. ----
  // Datenschutz-Vorbau fuers Server-Blur (Gruender-Auftrag): Screenshots duerfen keine
  // API-Keys/Passwoerter/IBANs leaken. Wir sammeln NUR GEOMETRIE (normalisiert 0..1 zum
  // Viewport, wie rect) - NIEMALS Feldinhalte. Erfasst werden:
  //   • input[type=password] IMMER,
  //   • input/textarea, deren Label/aria-label/placeholder/name/id auf sensible Begriffe
  //     matcht (API-Key, secret, token, Passwort, IBAN, Kontonummer, Kreditkarte, CVV, BIC),
  //   • beliebige Elemente mit [data-steply-sensitive] (Opt-in).
  // Sichtbar = im Viewport, Flaeche > 0, nicht display:none/visibility:hidden. Kappe bei 10
  // (die groessten zuerst), Werte 0..1 geklemmt (rectOf klemmt bereits).
  const SENSITIVE_RE =
    /(api[-_ ]?key|secret|token|geheim|passw|iban|kontonummer|kreditkarte|credit[-_ ]?card|cvv|bic)/i;
  const MAX_SENSITIVE = 10;

  // Trifft die BESCHRIFTUNG (Label/aria-label/placeholder/name/id) eines Feldes einen
  // sensiblen Begriff? NUR Metadaten des Feldes - NIE der eingegebene Wert.
  function isSensitiveByMeta(el) {
    try {
      const parts = [
        associatedLabelText(el),
        ariaLabelText(el),
        el.getAttribute && el.getAttribute("placeholder"),
        el.getAttribute && el.getAttribute("name"),
        el.id,
      ];
      const hay = parts.filter(Boolean).join(" ");
      return !!hay && SENSITIVE_RE.test(hay);
    } catch (err) {
      return false;
    }
  }

  // Sichtbar fuer die Schwaerzung: im Viewport, Flaeche > 0, nicht display:none/hidden.
  function isVisibleForRedaction(el) {
    if (!el || el.nodeType !== 1) return false;
    try {
      const cs = getComputedStyle(el);
      if (cs && (cs.display === "none" || cs.visibility === "hidden")) return false;
    } catch (err) {
      /* getComputedStyle kann werfen -> das Rect entscheidet */
    }
    let r;
    try {
      r = el.getBoundingClientRect();
    } catch (err) {
      return false;
    }
    if (!r || r.width <= 0 || r.height <= 0) return false;
    const vw = window.innerWidth || document.documentElement.clientWidth || 0;
    const vh = window.innerHeight || document.documentElement.clientHeight || 0;
    // Im Viewport, sobald es ihn ueberhaupt schneidet.
    if (r.bottom <= 0 || r.right <= 0 || r.top >= vh || r.left >= vw) return false;
    return true;
  }

  // Alle sichtbaren sensiblen Elemente -> normalisierte Rechtecke (0..1), groesste zuerst,
  // Kappe 10. Reine Geometrie; wirft nie (im Zweifel leere Liste).
  // asPx (Welle 48, iframes): statt normierter Rechtecke die PIXEL-Boxen dieses Fensters
  // ({left,top,width,height}) — das Hauptfenster rechnet sie auf seinen Viewport um.
  function collectSensitiveRects(asPx) {
    const seen = new Set();
    const rects = [];
    const add = (el) => {
      if (!el || el.nodeType !== 1 || seen.has(el)) return;
      seen.add(el);
      if (!isVisibleForRedaction(el)) return;
      const { rect, px } = rectOf(el);
      const area = rect.w * rect.h;
      if (!(area > 0)) return;
      rects.push({ x: rect.x, y: rect.y, w: rect.w, h: rect.h, area, px });
    };
    try {
      // 1) Passwortfelder IMMER.
      document.querySelectorAll('input[type="password"]').forEach(add);
      // 2) Opt-in per Attribut (beliebige Elemente).
      document.querySelectorAll("[data-steply-sensitive]").forEach(add);
      // 3) Text-Eingaben mit sensibler Beschriftung.
      document.querySelectorAll("input, textarea").forEach((el) => {
        if (isSensitiveByMeta(el)) add(el);
      });
    } catch (err) {
      /* im Zweifel lieber nichts erfassen als einen Fehler werfen */
    }
    rects.sort((a, b) => b.area - a.area);
    if (asPx) {
      return rects.slice(0, MAX_SENSITIVE).map((r) => ({
        left: r.px.left, top: r.px.top, width: r.px.width, height: r.px.height,
      }));
    }
    return rects.slice(0, MAX_SENSITIVE).map((r) => ({ x: r.x, y: r.y, w: r.w, h: r.h }));
  }

  // ============================================================================
  // SOFORT-ANLEITUNG: Schritte senden + Nachtraege (Welle 48)
  //
  // Nachrichten an das Panel (alle ueber chrome.runtime.sendMessage, NIE Feldinhalte):
  //   steply-guide-step    {step}                   neuer Schritt -> Panel macht SOFORT Screenshot
  //   steply-guide-patch   {ts, interaction}        interaction in den Schritt ts mergen
  //                                                 (Doppelklick, Ziehen & Ablegen)
  //   steply-guide-retract {ts}                     Schritt ts wieder entfernen (Rechtsklick ohne
  //                                                 eigenes Menue, Enter = Zeilenumbruch, Drag ohne Drop)
  //   steply-frame-geo     {key, rect, sensitive}   (nur Hauptfenster) echte Lage eines Schritts
  //                                                 aus einem iframe (step.frameKey === key)
  // ============================================================================

  // Schritt-Kennung: Date.now(), aber je Script-Instanz STRENG monoton — patch/retract
  // adressieren Schritte ueber ts, zwei Schritte derselben Millisekunde duerfen nicht kollidieren.
  let lastTs = 0;
  function nextTs() {
    const now = Date.now();
    lastTs = now > lastTs ? now : lastTs + 1;
    return lastTs;
  }

  function sendToPanel(msg) {
    try {
      const p = chrome.runtime.sendMessage(msg);
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch (err) {
      // Extension-Kontext weg (Reload) -> als beendet betrachten.
      recording = false;
    }
  }
  function sendPatch(ts, interaction) {
    if (!ts) return;
    sendToPanel({ type: "steply-guide-patch", ts, interaction });
  }
  function sendRetract(ts) {
    if (!ts) return;
    sendToPanel({ type: "steply-guide-retract", ts });
  }

  // iframe-Kennung fuer den Vertrag (interaction.frame.url): origin + pathname, ohne Query/Hash
  // (Tokens!). about:srcdoc/about:blank-Frames haben keine http-URL -> der Server verwirft frame
  // dann; die Markierungs-Umrechnung (frameKey) funktioniert trotzdem.
  function frameUrl() {
    try {
      if (/^https?:$/.test(location.protocol)) {
        return (location.origin + location.pathname).slice(0, 500);
      }
      return String(location.href || "").split(/[?#]/)[0].slice(0, 500);
    } catch (err) {
      return "";
    }
  }
  // Position dieses Frames unter den GLEICHARTIGEN Geschwister-Frames (gleiche Herkunft + Pfad),
  // z. B. Kartennummer/Ablauf/CVC als drei iframes derselben Seite. Nur gleich-herkuenftige
  // Geschwister sind lesbar — genau die koennen verwechselt werden. Beim Abspielen reagiert nur
  // der Frame mit derselben Nummer (sonst fuehrten alle gleichzeitig aus).
  function frameNth() {
    try {
      const p = window.parent;
      if (!p || p === window) return 0;
      const myPath = frameNormPath(location.pathname);
      let n = 0;
      for (let i = 0; i < p.frames.length; i++) {
        const w = p.frames[i];
        if (w === window) return n;
        try {
          if (w.location.origin === location.origin && frameNormPath(w.location.pathname) === myPath) n++;
        } catch (err) {
          /* fremde Herkunft -> kann nicht verwechselt werden */
        }
      }
    } catch (err) {
      /* egal */
    }
    return 0;
  }
  function randomKey() {
    let k = "";
    try {
      const a = new Uint32Array(4);
      crypto.getRandomValues(a);
      for (const n of a) k += n.toString(36);
    } catch (err) {
      k = "";
    }
    while (k.length < 16) k += Math.random().toString(36).slice(2);
    return k.slice(0, 24);
  }

  // Einen Schritt an das Panel senden. Die Seitenleiste macht darauf SOFORT einen Screenshot.
  // Der Klick-Puls (lastClickPx) wird erst NACH der Bestaetigung gezeichnet, damit er nie mit
  // im Bild landet. opts: { cx, cy (Fallback-Kreis), interaction, label (statt labelFor),
  // extra (zusaetzliche Schritt-Felder, z. B. fileMeta) }. el darf null sein (Tastenkuerzel
  // ohne Fokus-Element) -> leeres Rechteck. Rueckgabe: ts des Schritts.
  function emitStep(el, action, opts) {
    const o = opts || {};
    const geo = rectOf(el);
    lastClickPx = el
      ? {
          left: geo.px.left, top: geo.px.top, width: geo.px.width, height: geo.px.height,
          cx: o.cx != null ? o.cx : geo.px.cx, cy: o.cy != null ? o.cy : geo.px.cy,
        }
      : null;
    const ts = nextTs();
    const step = {
      rect: geo.rect,
      label: o.label || labelFor(el),
      action: action === "type" ? "type" : "click",
      url: (location && location.href ? location.href : "").slice(0, 500),
      title: truncate(document.title || "", 200),
      selector: selectorFor(el),
      ts,
    };
    if (o.extra) Object.assign(step, o.extra);
    const inter = o.interaction ? Object.assign({}, o.interaction) : {};
    let framePx = null;
    if (!IS_TOP) {
      // iframe: Rechtecke waeren relativ zum iframe, der Screenshot zeigt aber das ganze
      // Fenster. Markierung darum vorerst leer; die echte Lage reicht die Frame-Kette per
      // postMessage nach oben (onFrameGeo), das Hauptfenster meldet sie als steply-frame-geo.
      step.rect = { x: 0, y: 0, w: 0, h: 0 };
      inter.frame = { url: frameUrl(), nth: frameNth() };
      step.frameKey = randomKey();
      framePx = geo.px;
    } else {
      // Auto-Schwaerzung (Welle 28): nur GEOMETRIE sichtbarer sensibler Felder, additiv.
      const sensitive = collectSensitiveRects();
      if (sensitive.length) step.sensitive = sensitive;
    }
    if (Object.keys(inter).length) step.interaction = inter;
    sendToPanel({ type: "steply-guide-step", step });
    if (framePx) {
      postFrameGeo(step.frameKey, framePx, collectSensitiveRects(true));
    }
    return ts;
  }

  // SOFORT-ANLEITUNG / Datei-Bruecke (Welle 39): ein Upload-Schritt aus einem file-input.
  // NUR Metadaten (Rolle/Name/MIME/Groesse) reisen ans Panel — NIE die Datei-Bytes. Der Schritt
  // traegt den Selektor des INPUTS + foldPrevClick:true, damit das Panel den davor erfassten
  // „Datei auswaehlen"-Klick in DIESEN Schritt faltet (sonst entstuende beim Lauf ein sinnloser
  // Klick, der nur den OS-Dialog oeffnet). Screenshot laeuft wie bei jedem anderen Schritt.
  // fold=false (Welle 48): Datei per Drag & Drop aus dem Explorer auf eine Drop-Zone — davor gab
  // es KEINEN „Datei auswaehlen"-Klick, also nichts falten (sonst verschwaende ein echter Schritt).
  function emitUploadStep(inputEl, file, fold) {
    const extra = {
      // Datei-Bruecke: NUR Metadaten. filename/mime/size lokal ermittelt, gehen NIE an den Server.
      fileMeta: {
        role: "upload",
        filename: file && file.name ? String(file.name).slice(0, 200) : "",
        mime: file && file.type ? String(file.type).slice(0, 120) : "",
        size: file && typeof file.size === "number" ? file.size : 0,
      },
    };
    if (fold !== false) extra.foldPrevClick = true;
    return emitStep(inputEl, "click", {
      label: file && file.name ? clampLabel(file.name, 60) : "Datei",
      extra,
    });
  }

  // ---- iframes (Welle 48): Geometrie die Frame-Kette hinauf reichen -----------------------
  // Der iframe meldet seine Pixel-Box an window.parent; jedes uebergeordnete Content-Script
  // findet SEIN iframe-Element (contentWindow === event.source), addiert dessen Inhalts-Ursprung
  // und reicht weiter; das Hauptfenster normiert auf seinen Viewport und meldet ans Panel.
  // SICHERHEIT: die Nachricht aendert NUR die Markierungsposition eines Schritts mit passendem
  // Zufalls-key (nie Inhalte); nur Zahlen, ungueltige verworfen; nur von echten Kind-Frames.
  // ---- Geo-Kanal (Welle 48, Datenschutz) ----------------------------------------------------
  // Die Klick-Geometrie eines iframes reist NICHT per offenem window.postMessage nach oben (das
  // saehen die Skripte der einbettenden Seite — z. B. wo im Bank-iframe geklickt wurde — und
  // koennten es faelschen), sondern ueber einen PRIVATEN MessageChannel zwischen den Content-
  // Scripts: Das Kind bittet per „hello" (ohne Inhalt) um einen Kanal; das Eltern-Content-Script
  // schickt einen Port DIREKT an das Kind-Fenster (fuer die Eltern-Seite unsichtbar), belegt mit
  // dem Aufnahme-Geheimnis rec.nonce aus chrome.storage (fuer Seiten-Skripte unlesbar). Das Kind
  // nimmt nur einen Port mit passendem nonce an; Geo geht nur ueber diesen Port.
  let recNonce = "";
  let geoPort = null; // Kind: Port zum Eltern-Content-Script
  let geoQueue = []; // Kind: Geo-Nachrichten, bis der Port da ist
  let geoHelloAt = 0;
  function postFrameGeo(key, px, sensitivePx) {
    const msg = {
      key,
      rect: { left: px.left, top: px.top, width: px.width, height: px.height },
      sensitive: sensitivePx || [],
    };
    if (geoPort) {
      try {
        geoPort.postMessage(msg);
      } catch (err) {
        /* Port tot -> Markierung bleibt leer */
      }
      return;
    }
    geoQueue.push(msg);
    if (geoQueue.length > 20) geoQueue.shift();
    const now = Date.now();
    if (now - geoHelloAt < 1000) return;
    geoHelloAt = now;
    try {
      window.parent.postMessage({ __steplyGeoHello: 1 }, "*");
    } catch (err) {
      /* Eltern-Fenster nicht erreichbar -> Markierung bleibt leer */
    }
  }
  // Kind: Port vom Eltern-Content-Script annehmen (nur vom echten Eltern-Fenster + nonce).
  function onGeoPort(event) {
    const d = event.data;
    if (!d || typeof d !== "object" || d.__steplyGeoPort !== 1) return;
    if (IS_TOP || event.source !== window.parent) return;
    if (!recNonce || d.nonce !== recNonce || !event.ports || !event.ports[0]) return;
    geoPort = event.ports[0];
    const q = geoQueue;
    geoQueue = [];
    for (const m of q) {
      try {
        geoPort.postMessage(m);
      } catch (err) {
        /* egal */
      }
    }
  }
  window.addEventListener("message", onGeoPort);

  function cleanPx(r) {
    if (!r || typeof r !== "object") return null;
    const vals = [r.left, r.top, r.width, r.height];
    for (const n of vals) {
      if (typeof n !== "number" || !isFinite(n) || Math.abs(n) > 1e6) return null;
    }
    if (r.width < 0 || r.height < 0) return null;
    return { left: r.left, top: r.top, width: r.width, height: r.height };
  }

  // Das iframe-Element dieses Dokuments, dessen Fenster die Nachricht schickte. Zuerst die
  // normalen iframes, nur notfalls (gekappt) auch iframes in offenen Shadow-Roots.
  function findFrameElement(source) {
    const scan = (scope) => {
      let list = [];
      try {
        list = scope.querySelectorAll("iframe, frame");
      } catch (err) {
        list = [];
      }
      for (const f of list) {
        try {
          if (f.contentWindow === source) return f;
        } catch (err) {
          /* egal */
        }
      }
      return null;
    };
    const hit = scan(document);
    if (hit) return hit;
    let all = [];
    try {
      all = document.querySelectorAll("*");
    } catch (err) {
      all = [];
    }
    const roots = [];
    for (let i = 0; i < all.length && roots.length < 100; i++) {
      if (all[i].shadowRoot) roots.push(all[i].shadowRoot);
    }
    for (let i = 0; i < roots.length; i++) {
      const h = scan(roots[i]);
      if (h) return h;
      let inner = [];
      try {
        inner = roots[i].querySelectorAll("*");
      } catch (err) {
        inner = [];
      }
      for (let j = 0; j < inner.length && roots.length < 100; j++) {
        if (inner[j].shadowRoot) roots.push(inner[j].shadowRoot);
      }
    }
    return null;
  }

  // Inhalts-Box eines iframes im Viewport dieses Fensters (Rahmen + Padding abgezogen).
  function frameContentBox(f) {
    const r = f.getBoundingClientRect();
    let pl = 0, pt = 0, pr = 0, pb = 0;
    try {
      const cs = getComputedStyle(f);
      pl = parseFloat(cs.paddingLeft) || 0;
      pt = parseFloat(cs.paddingTop) || 0;
      pr = parseFloat(cs.paddingRight) || 0;
      pb = parseFloat(cs.paddingBottom) || 0;
    } catch (err) {
      /* ohne Padding */
    }
    return {
      left: r.left + (f.clientLeft || 0) + pl,
      top: r.top + (f.clientTop || 0) + pt,
      width: Math.max(0, (f.clientWidth || 0) - pl - pr),
      height: Math.max(0, (f.clientHeight || 0) - pt - pb),
    };
  }

  // In den Eltern-Viewport verschieben und auf die sichtbare iframe-Flaeche beschneiden.
  function shiftIntoBox(r, box) {
    const l = Math.max(r.left + box.left, box.left);
    const t = Math.max(r.top + box.top, box.top);
    const rr = Math.min(r.left + box.left + r.width, box.left + box.width);
    const bb = Math.min(r.top + box.top + r.height, box.top + box.height);
    return { left: l, top: t, width: Math.max(0, rr - l), height: Math.max(0, bb - t) };
  }

  // Eltern: ein Kind-Frame bittet um einen Kanal → Port DIREKT an dieses Kind-Fenster schicken.
  function onGeoHello(event) {
    const d = event.data;
    if (!d || typeof d !== "object" || d.__steplyGeoHello !== 1) return;
    if (!recording || mode !== "guide" || !recNonce) return;
    if (!event.source || event.source === window) return;
    const frame = findFrameElement(event.source);
    if (!frame) return; // nur echte Kind-Frames DIESES Dokuments
    let ch;
    try {
      ch = new MessageChannel();
    } catch (err) {
      return;
    }
    ch.port1.onmessage = (e) => onFrameGeo(e.data, frame);
    try {
      event.source.postMessage({ __steplyGeoPort: 1, nonce: recNonce }, "*", [ch.port2]);
    } catch (err) {
      /* Kind weg */
    }
  }
  window.addEventListener("message", onGeoHello);

  // Eltern: Geo aus dem privaten Kanal eines Kind-Frames umrechnen und weiterreichen.
  function onFrameGeo(d, frame) {
    if (!d || typeof d !== "object") return;
    if (!recording || mode !== "guide") return;
    if (!frame || !frame.isConnected) return;
    const key = typeof d.key === "string" && /^[a-z0-9]{8,40}$/.test(d.key) ? d.key : "";
    const rect = cleanPx(d.rect);
    if (!key || !rect) return;
    const sens = Array.isArray(d.sensitive)
      ? d.sensitive.slice(0, MAX_SENSITIVE).map(cleanPx).filter(Boolean)
      : [];
    let box;
    try {
      box = frameContentBox(frame);
    } catch (err) {
      return;
    }
    const outRect = shiftIntoBox(rect, box);
    const outSens = sens
      .map((r) => shiftIntoBox(r, box))
      .filter((r) => r.width > 0 && r.height > 0);
    if (!IS_TOP) {
      postFrameGeo(key, outRect, outSens);
      return;
    }
    const norm = (r) => normRect(r.left, r.top, r.width, r.height);
    // Sensible Felder: die des iframes (umgerechnet) + die des Hauptfensters (auch die sind im
    // Screenshot sichtbar). Kappe wie collectSensitiveRects.
    const sensitive = outSens
      .map(norm)
      .filter((r) => r.w * r.h > 0)
      .concat(collectSensitiveRects())
      .slice(0, MAX_SENSITIVE);
    sendToPanel({ type: "steply-frame-geo", key, rect: norm(outRect), sensitive });
  }

  // Ist ein editierbares Feld mit GEAENDERTEM Wert fokussiert, ZUERST den Eingabe-Schritt
  // senden und das Feld abrechnen (settled) - damit ein direkt folgender Klick DAHINTER
  // liegt und das nachfolgende blur keinen Doppel-Schritt erzeugt.
  function flushPendingInput() {
    const fe = focusedEditable;
    if (!fe || !fe.el || fe.settled) return false;
    const now = fieldSnapshot(fe.el, fe.kind);
    if (now === fe.startValue) return false;
    fe.settled = true;
    emitStep(fe.el, "type");
    return true;
  }
  // Wie oben, aber nur, wenn das Ziel NICHT im fokussierten Feld liegt.
  function flushUnlessInside(target) {
    const fe = focusedEditable;
    const inside = !!(
      fe && fe.el && (target === fe.el || (fe.el.contains && fe.el.contains(target)))
    );
    if (!inside) flushPendingInput();
  }

  // ---- Hover-Menues (Welle 48) -----------------------------------------------------------
  // Klickt man einen Eintrag in einem per Maus-DRUEBER geoeffneten Menue, braucht die Wiedergabe
  // vorher ein Hover auf den Ausloeser. Erkennung KONSERVATIV (lieber kein hover als ein falsches):
  //   (a) ARIA: ein Element mit aria-expanded="true" ist Vorfahre des Ziels (mit Menue-Container
  //       dazwischen) ODER zeigt per aria-controls / als direktes Geschwister auf ein Menue, in
  //       dem das Ziel liegt;
  //   (b) der vorige erfasste Klick-Schritt galt NICHT diesem Ausloeser (sonst per Klick geoeffnet);
  //   (c) der Mauszeiger war in den letzten 5 s ueber dem Ausloeser (mouseover, nur Referenzen).
  // Reine CSS-:hover-Menues (ohne ARIA) erkennen wir bewusst NICHT: sicher prüfbar waere das nur
  // ueber die Stylesheet-Regeln (display/visibility per :hover) — zu teuer und zu fehleranfaellig.
  const HOVER_TRIGGER_SEL = '[aria-haspopup]:not([aria-haspopup="false"]), [aria-expanded]';
  const MENU_CONTAINER_SEL = '[role="menu"], [role="menubar"], [role="listbox"], [role="group"], ul, ol';
  const HOVER_RECENT_MS = 5000;
  let hoverSeen = []; // [{ el, t }] — die letzten Ausloeser unter dem Zeiger (max. 8)

  function onMouseOver(event) {
    if (!recording || mode !== "guide") return;
    const trig = closestDeep(realTarget(event), HOVER_TRIGGER_SEL);
    if (!trig) return;
    const now = Date.now();
    const last = hoverSeen[hoverSeen.length - 1];
    if (last && last.el === trig) {
      last.t = now;
      return;
    }
    hoverSeen = hoverSeen.filter((h) => h.el !== trig && now - h.t <= HOVER_RECENT_MS);
    hoverSeen.push({ el: trig, t: now });
    if (hoverSeen.length > 8) hoverSeen.shift();
  }
  document.addEventListener("mouseover", onMouseOver, true);

  // Hover-Ausloeser fuer ein Klick-Ziel oder null. Rueckgabe { selector, label }.
  function hoverFor(el) {
    if (!el || el.nodeType !== 1) return null;
    try {
      const chain = [];
      for (let n = flatParent(el), i = 0; n && i < 60; n = flatParent(n), i++) chain.push(n);
      const depthOf = (x) => (x === el ? 0 : chain.indexOf(x) + 1); // 0 = el, -: nicht drin
      let best = null; // { trig, depth } — das dem Ziel naechste Menue gewinnt
      const consider = (trig, depth) => {
        if (depth <= 0) return;
        if (!best || depth < best.depth) best = { trig, depth };
      };
      // (a1) Vorfahre mit aria-expanded="true" UND ein Menue-Container zwischen ihm und dem Ziel
      // (sonst ist es ein Klick auf den Ausloeser selbst).
      for (let i = 0; i < chain.length; i++) {
        const n = chain[i];
        if (n.nodeType !== 1 || !n.getAttribute || n.getAttribute("aria-expanded") !== "true") continue;
        let menuBetween = false;
        for (let j = 0; j < i; j++) {
          if (chain[j].nodeType === 1 && chain[j].matches && chain[j].matches(MENU_CONTAINER_SEL)) {
            menuBetween = true;
            break;
          }
        }
        if (menuBetween) consider(n, i + 1);
        break; // nur der innerste expandierte Vorfahre
      }
      // (a2) aria-controls bzw. direktes Geschwister-Menue
      const scopes = [document];
      const sr = shadowRootOf(el);
      if (sr) scopes.push(sr);
      for (const sc of scopes) {
        let list = [];
        try {
          list = sc.querySelectorAll('[aria-expanded="true"]');
        } catch (err) {
          list = [];
        }
        for (const t of list) {
          if (t === el || depthOf(t) > 0) continue;
          const ctl = t.getAttribute("aria-controls");
          if (ctl) {
            const sco = scopeOf(t);
            for (const id of ctl.split(/\s+/)) {
              const m = id && sco.getElementById ? sco.getElementById(id) : null;
              if (m) consider(t, depthOf(m));
            }
          }
          const sib = t.nextElementSibling;
          if (sib) consider(t, depthOf(sib));
        }
      }
      if (!best) return null;
      const trig = best.trig;
      if (trig === el || el.contains(trig)) return null;
      // Eingabe-Ausloeser (Autocomplete-Combobox) oeffnen per Tippen, nicht per Hover.
      if (editableInfo(trig).editable) return null;
      // (b) per Klick geoeffnet? Nicht nur der letzte Klick: in einem Mehrfach-Dropdown folgen
      // auf den Oeffnen-Klick mehrere Auswahl-Klicks, das Menue bleibt offen.
      const tNow = Date.now();
      if (
        recentClicks.some(
          (c) => tNow - c.at <= CLICK_OPENED_MS && c.el && (c.el === trig || c.el.contains(trig))
        )
      ) {
        return null;
      }
      // (c) kuerzlich unter dem Zeiger?
      const now = Date.now();
      const hovered = hoverSeen.some(
        (h) =>
          now - h.t <= HOVER_RECENT_MS &&
          h.el &&
          (h.el === trig || trig.contains(h.el) || h.el.contains(trig))
      );
      if (!hovered) return null;
      const selector = selectorFor(trig);
      if (!selector) return null;
      return { selector, label: labelFor(trig) };
    } catch (err) {
      return null;
    }
  }

  // ---- Klick / Doppelklick / Zeiger-Ziehen ------------------------------------------------
  const DOUBLE_MS = 500;
  const DRAG_MIN_PX = 40;
  let lastClickStep = null; // { el, ts, at, doubled } — letzter per Zeiger erfasster Klick
  const CLICK_OPENED_MS = 60000; // so lange gilt ein Menue als „per Klick geoeffnet"
  let recentClicks = []; // [{ el, at }] — die letzten Klick-Schritte (Hover-Erkennung (b))
  let pendingDown = null; // pointerdown wartet auf mousedown.detail (Doppelklick?)
  let dragProbe = null; // { el, ts, x, y } — pointerdown eines Klick-Schritts (fuer Ziehen)

  function emitClick(el, x, y) {
    const opts = { cx: x, cy: y };
    const hover = hoverFor(el);
    if (hover) {
      opts.interaction = { hover: hover.selector };
      if (hover.label) opts.interaction.hoverLabel = hover.label;
    }
    const ts = emitStep(el, "click", opts);
    lastClickStep = { el, ts, at: Date.now(), doubled: false };
    recentClicks.push({ el, at: lastClickStep.at });
    if (recentClicks.length > 12) recentClicks.shift();
    dragProbe = { el, ts, x, y };
    return ts;
  }

  // Zweiter Druck eines Doppelklicks: KEIN neuer Schritt, sondern der erste wird „double".
  function markDouble(lc) {
    if (!lc.doubled) {
      lc.doubled = true;
      sendPatch(lc.ts, { variant: "double" });
    }
    dragProbe = null;
  }

  // SOFORT-ANLEITUNG (guide-Modus): auf pointerdown (Capture-Phase, VOR Klick-Wirkung und
  // Navigation) das geklickte Element erfassen. Ein Klick IN ein editierbares Feld erzeugt
  // KEINEN Schritt mehr - dessen Inhalt meldet erst das blur als Eingabe-Schritt (Tango).
  function onPointerDown(event) {
    if (!recording || mode !== "guide") return;
    // Nur Haupt-Taste (linksklick / primaerer Zeiger).
    if (typeof event.button === "number" && event.button !== 0) return;

    const target = realTarget(event);
    watchShadowRoots(target);
    dragProbe = null;
    pendingDown = null;
    html5Drag = null;

    // EVENT-REIHENFOLGE (kritisch): pointerdown(Button) feuert VOR blur(Feld). Klickt man
    // ausserhalb des fokussierten Feldes, erst die Eingabe melden, dann den Klick.
    // Der Flush laeuft VOR dem Dead-Click-Filter: auch ein Klick ins Leere schliesst eine
    // offene Eingabe ab.
    flushUnlessInside(target);

    // DEAD-CLICK-FILTER: Klick auf nicht-interaktive Flaeche (passive Karte, Absatz,
    // Leerraum) erzeugt KEINEN Schritt.
    const el = interactiveFor(target);
    if (!el) return;

    // Klick IN ein editierbares Feld erzeugt KEINEN Schritt (kein Feld-Klick-Rauschen).
    const info = editableInfo(controlForLabel(el));
    if (info.editable) return;

    // Schieberegler (input type=range): der Schritt entsteht beim change (Endposition im
    // Screenshot), nicht beim Anfassen.
    const elTag = (el.tagName || "").toLowerCase();
    const elType = ((el.getAttribute && el.getAttribute("type")) || "").toLowerCase();
    if (elTag === "input" && elType === "range") return;

    const x = event.clientX || 0;
    const y = event.clientY || 0;
    // DOPPELKLICK: zweiter Druck auf dasselbe Element binnen 500 ms. Chrome liefert an
    // pointerdown detail=0 — der Klickzaehler kommt erst mit dem mousedown derselben Eingabe
    // (gleiche Task). Darum kurz aufschieben; kommt kein mousedown (Seite unterdrueckt es per
    // preventDefault am pointerdown), gilt es nach setTimeout 0 als normaler Klick.
    const lc = lastClickStep;
    if (lc && lc.el === el && Date.now() - lc.at <= DOUBLE_MS) {
      if (event.detail >= 2) {
        markDouble(lc);
        return;
      }
      const pd = { el, x, y };
      pendingDown = pd;
      setTimeout(() => {
        if (pendingDown !== pd) return;
        pendingDown = null;
        emitClick(pd.el, pd.x, pd.y);
      }, 0);
      return;
    }
    emitClick(el, x, y);
  }

  // pointerdown feuert VOR click und VOR der Navigation -> der Screenshot zeigt die Seite
  // im Ausgangszustand (mit dem Element, das gleich geklickt wird).
  document.addEventListener("pointerdown", onPointerDown, true);

  function onMouseDown(event) {
    const pd = pendingDown;
    if (!pd) return;
    pendingDown = null;
    if (!recording || mode !== "guide") return;
    const lc = lastClickStep;
    if (event.button === 0 && event.detail >= 2 && lc && lc.el === pd.el) {
      markDouble(lc);
      return;
    }
    emitClick(pd.el, pd.x, pd.y);
  }
  document.addEventListener("mousedown", onMouseDown, true);

  // Sieht die Quelle nach Zieh-Griff aus? (Sortier-Listen ohne HTML5-DnD.) Konservativ: Cursor
  // grab/move oder typische Drag-Attribute an der Quelle bzw. bis zu 3 Ebenen darueber, oder
  // der Zieh-Cursor am body (viele Bibliotheken setzen ihn waehrend des Ziehens).
  function looksDraggable(el) {
    const DRAG_CURSOR = /^(grab|grabbing|move|all-scroll|-webkit-grab|-webkit-grabbing)$/;
    let n = el;
    for (let i = 0; n && n.nodeType === 1 && i < 4; i++, n = flatParent(n)) {
      try {
        if (DRAG_CURSOR.test(getComputedStyle(n).cursor)) return true;
      } catch (err) {
        /* egal */
      }
      const g = n.getAttribute ? n : null;
      if (g) {
        if (g.hasAttribute("aria-grabbed") || g.hasAttribute("data-rbd-drag-handle-draggable-id")) return true;
        if (g.hasAttribute("data-drag-handle") || g.hasAttribute("data-sortable-handle")) return true;
        const rd = g.getAttribute("aria-roledescription") || "";
        if (/drag|zieh|sortier|sortable|verschieb/i.test(rd)) return true;
      }
    }
    try {
      if (document.body && DRAG_CURSOR.test(getComputedStyle(document.body).cursor)) return true;
    } catch (err) {
      /* egal */
    }
    return false;
  }

  // Interaktives Element unter dem Loslass-Punkt, das NICHT zur Quelle gehoert (die gezogene
  // Kopie liegt oft direkt unter dem Zeiger). Oberstes fremdes Element nicht interaktiv -> null.
  function dropTargetAt(x, y, srcEl) {
    let list = [];
    try {
      list = document.elementsFromPoint(x, y);
    } catch (err) {
      list = [];
    }
    for (let e of list) {
      for (let i = 0; e && e.shadowRoot && i < 5; i++) {
        let inner = null;
        try {
          inner = e.shadowRoot.elementFromPoint(x, y);
        } catch (err) {
          inner = null;
        }
        if (!inner || inner === e) break;
        e = inner;
      }
      if (!e || e === srcEl || srcEl.contains(e) || e.contains(srcEl)) continue;
      const it = interactiveFor(e);
      if (it && it !== srcEl && !srcEl.contains(it) && !it.contains(srcEl)) return it;
      return null;
    }
    return null;
  }

  // Zeiger-Ziehen OHNE DnD-Events (Sortier-Listen): pointerdown eines Klick-Schritts, pointerup
  // >40 px entfernt auf einem ANDEREN interaktiven Element -> den Klick-Schritt zu „drag" patchen.
  // (Ein click-Event kommt erst NACH pointerup — und landet bei Zieh-Gesten am gemeinsamen
  // Vorfahren; darum entscheiden Distanz + Zieh-Griff + fremdes Ziel.)
  function onPointerUp(event) {
    const dp = dragProbe;
    dragProbe = null;
    if (!dp || !recording || mode !== "guide") return;
    if (typeof event.button === "number" && event.button !== 0) return;
    const x = event.clientX || 0;
    const y = event.clientY || 0;
    if (Math.hypot(x - dp.x, y - dp.y) <= DRAG_MIN_PX) return;
    if (!looksDraggable(dp.el)) return;
    const dropEl = dropTargetAt(x, y, dp.el);
    if (!dropEl) return;
    const drop = selectorFor(dropEl);
    if (!drop) return;
    const inter = { variant: "drag", drop };
    const dl = labelFor(dropEl);
    if (dl) inter.dropLabel = dl;
    sendPatch(dp.ts, inter);
  }
  document.addEventListener("pointerup", onPointerUp, true);

  // ---- HTML5 Drag & Drop + Datei-Drop (Welle 48) -------------------------------------------
  const DROP_CONTAINER_SEL =
    '[aria-dropeffect], [dropzone], [role="listitem"], [role="row"], [role="gridcell"], ' +
    '[role="list"], [role="listbox"], [role="grid"], [role="tree"], [role="treeitem"], ' +
    '[role="region"], li, ul, ol, td, tr, section';
  let html5Drag = null; // { ts, emitted, dropped }

  // dragstart: Quelle merken. Gab es fuer sie schon einen Klick-Schritt (pointerdown), wird
  // DER beim drop gepatcht; sonst (nicht-interaktive draggable-Kachel) jetzt einen Schritt
  // senden — und ihn zuruecknehmen, falls nie abgelegt wird (dragend ohne drop).
  function onDragStart(event) {
    if (!recording || mode !== "guide") return;
    const t = realTarget(event);
    const src = closestDeep(t, '[draggable="true"]') || t;
    const dp = dragProbe;
    dragProbe = null;
    if (dp && dp.el && (dp.el === src || dp.el.contains(src) || src.contains(dp.el))) {
      html5Drag = { ts: dp.ts, emitted: false, dropped: false };
      return;
    }
    const el = interactiveFor(src) || src;
    if (!el || el.nodeType !== 1) return;
    html5Drag = { ts: emitStep(el, "click"), emitted: true, dropped: false };
  }
  document.addEventListener("dragstart", onDragStart, true);

  function onDrop(event) {
    if (!recording || mode !== "guide") return;
    const t = realTarget(event);
    const hd = html5Drag;
    if (!hd) {
      // Datei aus dem Explorer auf eine Drop-Zone -> Upload-Schritt (Datei-Bruecke, nur Metadaten).
      let files = null;
      try {
        files = event.dataTransfer && event.dataTransfer.files;
      } catch (err) {
        files = null;
      }
      if (files && files.length) {
        const zone = interactiveFor(t) || closestDeep(t, DROP_CONTAINER_SEL) || t;
        if (zone && zone.nodeType === 1) emitUploadStep(zone, files[0], false);
      }
      return;
    }
    hd.dropped = true;
    html5Drag = null; // dragend erreicht uns evtl. nie (Quelle beim Ablegen entfernt)
    const dropEl = interactiveFor(t) || closestDeep(t, DROP_CONTAINER_SEL) || t;
    const drop = dropEl && dropEl.nodeType === 1 ? selectorFor(dropEl) : undefined;
    if (!drop) return;
    const inter = { variant: "drag", drop };
    const dl = labelFor(dropEl);
    if (dl) inter.dropLabel = dl;
    sendPatch(hd.ts, inter);
  }
  document.addEventListener("drop", onDrop, true);

  function onDragEnd() {
    const hd = html5Drag;
    html5Drag = null;
    if (hd && hd.emitted && !hd.dropped && recording && mode === "guide") sendRetract(hd.ts);
  }
  document.addEventListener("dragend", onDragEnd, true);

  // ---- Rechtsklick (Welle 48) -------------------------------------------------------------
  // Nur aufnehmbar, wenn die Seite ein EIGENES Kontextmenue zeigt (das Browser-Menue laesst sich
  // nicht abspielen). Ob sie das tut (preventDefault), wissen wir erst NACH der Auslieferung —
  // darum SOFORT senden (Screenshot vor dem Menue) und notfalls zuruecknehmen.
  function onContextMenu(event) {
    if (!recording || mode !== "guide") return;
    const target = realTarget(event);
    watchShadowRoots(target);
    flushUnlessInside(target);
    const el = interactiveFor(target) || target;
    if (!el || el.nodeType !== 1 || el === document.body || el === document.documentElement) return;
    const ts = emitStep(el, "click", {
      cx: event.clientX || 0,
      cy: event.clientY || 0,
      interaction: { variant: "right" },
    });
    setTimeout(() => {
      if (!event.defaultPrevented) sendRetract(ts);
    }, 0);
  }
  document.addEventListener("contextmenu", onContextMenu, true);

  // focusin: Startwert eines editierbaren Feldes merken (bleibt LOKAL, nie ans Panel).
  function onFocusIn(event) {
    if (!recording || mode !== "guide") return;
    const target = realTarget(event);
    watchShadowRoots(target);
    const info = editableInfo(target);
    if (!info.editable) {
      focusedEditable = null;
      return;
    }
    // Dasselbe Ereignis kann am Shadow-Root UND am document ankommen -> nicht neu starten.
    if (focusedEditable && focusedEditable.el === info.control) return;
    focusedEditable = {
      el: info.control,
      kind: info.kind,
      startValue: fieldSnapshot(info.control, info.kind),
      settled: false,
    };
  }
  document.addEventListener("focusin", onFocusIn, true);

  // Feld nachtraeglich uebernehmen, wenn es fokussiert wurde, BEVOR die Aufnahme scharf war
  // (Google setzt den Cursor schon beim Laden ins Suchfeld -> kein focusin fuer uns).
  // unknownStart: der Startwert ist unbekannt (es wurde schon getippt) -> „leer" annehmen.
  function adoptEditable(el, unknownStart) {
    const info = editableInfo(el);
    if (!info.editable) return null;
    if (focusedEditable && focusedEditable.el === info.control) return focusedEditable;
    focusedEditable = {
      el: info.control,
      kind: info.kind,
      startValue: unknownStart
        ? (info.kind === "rich" ? "len:0" : "")
        : fieldSnapshot(info.control, info.kind),
      settled: false,
    };
    return focusedEditable;
  }

  // input: Tippen in ein nicht erfasstes Feld (s. o.) -> jetzt uebernehmen.
  function onInput(event) {
    if (!recording || mode !== "guide") return;
    const target = realTarget(event);
    if (focusedEditable && focusedEditable.el === target) {
      const fe = focusedEditable;
      if (fe.settled && typeof fe.settledValue === "string") {
        const now = fieldSnapshot(fe.el, fe.kind);
        if (now !== fe.settledValue) {
          fe.startValue = fe.settledValue;
          fe.settled = false;
          fe.settledValue = undefined;
        }
      }
      return;
    }
    // contenteditable: input feuert am Editier-Wurzelelement; innere Knoten zaehlen mit.
    if (focusedEditable && focusedEditable.el && focusedEditable.el.contains &&
        focusedEditable.el.contains(target)) return;
    adoptEditable(target, true);
  }
  document.addEventListener("input", onInput, true);

  // Schickt Enter in diesem Feld typischerweise ab? Einzeilige Felder ja; ein textarea nur,
  // wenn es sich als Such-/Kombifeld ausweist (Google-Suche ist ein textarea) — in einem
  // normalen mehrzeiligen Feld ist Enter ein Zeilenumbruch.
  function enterSubmits(fe) {
    const el = fe.el;
    const tag = (el.tagName || "").toLowerCase();
    if (tag === "input") return fe.kind === "text" || fe.kind === "password";
    if (tag !== "textarea") return false;
    const role = ((el.getAttribute && el.getAttribute("role")) || "").toLowerCase();
    if (role === "combobox" || role === "searchbox") return true;
    if (el.getAttribute && el.getAttribute("aria-autocomplete")) return true;
    try {
      return !!(el.closest && el.closest('[role="search"], form[action*="search"]'));
    } catch (err) {
      return false;
    }
  }

  // ---- Enter in Chat-/Editor-Feldern (contenteditable, Welle 48) ---------------------------
  // In Chats (Teams, Slack, Tickets) schickt Enter ab, in Editoren ist es ein Zeilenumbruch.
  // Beides sieht beim keydown gleich aus. Darum: Schritt SOFORT senden (Screenshot zeigt die
  // getippte Nachricht), nach 400 ms nachsehen: Feld leer oder weg -> war Absenden (bleibt);
  // Inhalt noch da -> Zeilenumbruch -> Schritt zuruecknehmen, Feld offen lassen (blur meldet
  // spaeter den normalen Eingabe-Schritt). Gelesen wird NUR die Textlaenge, lokal.
  const RICH_ENTER_PROBE_MS = 400;
  // Gleiche Probe fuer mehrzeilige <textarea>-Chatfelder (ChatGPT u. ae.): dort zaehlt der Wert.
  function richTextLen(el) {
    try {
      const raw = (el.tagName || "").toLowerCase() === "textarea" ? el.value : el.textContent;
      return (raw || "").replace(/[\s​-‍﻿]/g, "").length;
    } catch (err) {
      return 0;
    }
  }
  function probeRichEnter(fe) {
    if (fieldSnapshot(fe.el, fe.kind) === fe.startValue) return;
    fe.settled = true;
    const el = fe.el;
    const ts = emitStep(el, "type", { interaction: { enter: true } });
    setTimeout(() => {
      if (!recording || mode !== "guide") return;
      if (!el.isConnected || richTextLen(el) === 0) {
        // Abgeschickt. Bleibt das Feld fokussiert (naechste Nachricht), neu „scharf" stellen.
        if (focusedEditable === fe) {
          fe.startValue = fieldSnapshot(el, fe.kind);
          fe.settled = false;
        }
        return;
      }
      sendRetract(ts);
      if (focusedEditable === fe) fe.settled = false;
      else emitStep(el, "type"); // Feld schon verlassen: dessen blur ist verpasst -> jetzt melden
    }, RICH_ENTER_PROBE_MS);
  }

  // ---- Tastenkuerzel (Welle 48) -----------------------------------------------------------
  // keydown mit Ctrl/Cmd/Alt + Taste -> Schritt variant "key" mit Anzeige-Form „Ctrl+S".
  // KEIN Schritt: reine Modifier, Escape/Tab/Pfeile, Wiederholung (gedrueckt halten),
  // AltGr-Zeichen (Ctrl+Alt+Q = @ auf deutscher Tastatur), Textbearbeitung in Feldern
  // (Ctrl/Cmd + C/V/X/A/Z/Y, Loeschen/Pos1/Ende), Mac-Option-Sonderzeichen in Feldern.
  const MODIFIER_KEYS =
    /^(Control|Shift|Alt|AltGraph|Meta|OS|Win|CapsLock|NumLock|ScrollLock|Fn|FnLock|Hyper|Super|Dead|Process|Unidentified)$/;
  const NO_STEP_KEYS = /^(Escape|Esc|Tab|ArrowUp|ArrowDown|ArrowLeft|ArrowRight|Up|Down|Left|Right)$/;
  const IS_MAC = (() => {
    try {
      return /Mac|iPhone|iPad/i.test((navigator.platform || "") + " " + (navigator.userAgent || ""));
    } catch (err) {
      return false;
    }
  })();

  // Haupttaste in Anzeige-Form: Buchstaben/Ziffern bevorzugt ueber event.key (die BESCHRIFTETE
  // Taste — auf deutscher QWERTZ-Tastatur ist Strg+Z code „KeyY"!), sonst ueber event.code
  // (Shift-/Option-Sonderzeichen), sonst benannte Tasten (F5, Enter, Delete, …); Space als „Space".
  function shortcutKeyName(event) {
    const code = event.code || "";
    const key = event.key || "";
    if (/^[a-z0-9]$/i.test(key)) return key.toUpperCase();
    let m = /^Key([A-Z])$/.exec(code);
    if (m) return m[1];
    m = /^Digit(\d)$/.exec(code);
    if (m) return m[1];
    const k = event.key || "";
    if (k === " " || code === "Space") return "Space";
    if (k.length === 1) return k.toUpperCase();
    if (/^[A-Za-z][A-Za-z0-9]{0,19}$/.test(k)) return k;
    return "";
  }

  function onShortcut(event, target) {
    if (event.repeat) return;
    const k = event.key || "";
    if (!k || MODIFIER_KEYS.test(k) || NO_STEP_KEYS.test(k)) return;
    try {
      if (event.getModifierState && event.getModifierState("AltGraph")) return;
    } catch (err) {
      /* egal */
    }
    if (event.ctrlKey && event.altKey && k.length === 1) return; // AltGr-Zeichen (@ € { …)
    const primary = event.ctrlKey || event.metaKey;
    const info = editableInfo(controlForLabel(target));
    const inEditable = info.editable || !!(target && target.isContentEditable === true);
    if (inEditable) {
      if (primary && (/^Key[CVXAZY]$/.test(event.code || "") || /^[cvxazy]$/i.test(k))) return;
      if (/^(Backspace|Delete|Home|End|PageUp|PageDown)$/.test(k)) return;
      if (IS_MAC && event.altKey && !primary) return; // Option+Taste = Sonderzeichen
    }
    const name = shortcutKeyName(event);
    if (!name) return;
    const parts = [];
    if (event.ctrlKey) parts.push("Ctrl");
    if (event.metaKey) parts.push(IS_MAC ? "Cmd" : "Meta");
    if (event.altKey) parts.push("Alt");
    if (event.shiftKey) parts.push("Shift");
    parts.push(name);
    const combo = parts.join("+");
    // Offene Eingabe zuerst melden (getippt VOR dem Kuerzel) — das Feld bleibt offen, spaeteres
    // Weitertippen wird beim Verlassen wieder erfasst.
    const fe = focusedEditable;
    if (fe && fe.el && !fe.settled) {
      const now = fieldSnapshot(fe.el, fe.kind);
      if (now !== fe.startValue) {
        emitStep(fe.el, "type");
        fe.startValue = now;
      }
    }
    const active = deepActiveElement();
    const el =
      active && active.nodeType === 1 && active !== document.body && active !== document.documentElement
        ? active
        : null;
    emitStep(el, "click", { interaction: { variant: "key", key: combo }, label: el ? "" : combo });
  }

  // keydown: Tastenkuerzel (s. o.) und Enter. Enter in einem einzeiligen Feld: die Seite
  // schickt gleich ab und navigiert weg — blur kommt dann NIE. Den Eingabe-Schritt darum JETZT
  // melden (Screenshot zeigt noch das ausgefuellte Feld). Auch ein Enter ohne Aenderung
  // (vorbefuelltes Feld abschicken) ist ein echter Schritt. contenteditable: probeRichEnter.
  function onKeyDown(event) {
    if (!recording || mode !== "guide") return;
    if (event.isComposing) return;
    const target = realTarget(event);
    watchShadowRoots(target);
    if (event.ctrlKey || event.metaKey || event.altKey) {
      onShortcut(event, target);
      return;
    }
    if (event.key !== "Enter" || event.shiftKey) return;
    const fe = adoptEditable(target, false);
    if (!fe || fe.settled) return;
    if (enterSubmits(fe)) {
      fe.settled = true;
      // Wert beim Absenden merken: tippt man danach weiter (zweite Suche im selben Feld),
      // oeffnet onInput das Feld wieder (sonst ginge das zweite Enter verloren).
      fe.settledValue = fieldSnapshot(fe.el, fe.kind);
      emitStep(fe.el, "type", { interaction: { enter: true } });
      return;
    }
    if (fe.kind === "rich" || (fe.el.tagName || "").toLowerCase() === "textarea") probeRichEnter(fe);
  }
  document.addEventListener("keydown", onKeyDown, true);

  // focusout: verlaesst man ein Feld mit GEAENDERTEM Wert, einen „type"-Schritt senden. Der
  // Screenshot entsteht damit NACH der Eingabe und zeigt das ausgefuellte Feld (gewollt).
  function onFocusOut(event) {
    if (!recording || mode !== "guide") return;
    const fe = focusedEditable;
    if (!fe || realTarget(event) !== fe.el) return;
    focusedEditable = null;
    if (fe.settled) return; // bereits per pointerdown-Flush abgerechnet
    const now = fieldSnapshot(fe.el, fe.kind);
    if (now !== fe.startValue) emitStep(fe.el, "type");
  }
  document.addEventListener("focusout", onFocusOut, true);

  // change: native <select> und Schieberegler (input type=range) -> ein „type"-Schritt
  // (sichtbare UI-Auswahl/-Position, kein Getipptes). Range feuert change je Raststufe
  // (Tastatur) bzw. beim Loslassen — pro Element gedrosselt, damit Feinjustieren nicht
  // zehn Schritte erzeugt (der Screenshot zeigt dann die letzte erfasste Position).
  // Shadow DOM: change ist nicht composed -> watchShadowRoots haengt denselben Listener an
  // jeden beruehrten Root (event.target ist dort das echte Element).
  let lastRangeStep = { el: null, t: 0 };
  function onChange(event) {
    if (!recording || mode !== "guide") return;
    const el = event.target;
    if (!el) return;
    const tag = (el.tagName || "").toLowerCase();
    const type = ((el.getAttribute && el.getAttribute("type")) || "").toLowerCase();
    // Datei-Bruecke (Welle 39): file-input mit gewaehlter Datei → eigener Upload-Schritt.
    if (tag === "input" && type === "file") {
      const files = el.files;
      if (files && files.length) emitUploadStep(el, files[0]);
      return;
    }
    const isSelect = tag === "select";
    const isRange = tag === "input" && type === "range";
    if (!isSelect && !isRange) return;
    if (isRange) {
      const now = Date.now();
      if (lastRangeStep.el === el && now - lastRangeStep.t < 1200) {
        lastRangeStep.t = now;
        return;
      }
      lastRangeStep = { el, t: now };
    }
    emitStep(el, "type");
    // Feld abrechnen, damit das folgende blur keinen Doppel-Schritt erzeugt.
    if (isSelect && focusedEditable && focusedEditable.el === el) {
      focusedEditable.startValue = fieldSnapshot(el, "select");
      focusedEditable.settled = true;
    }
  }
  document.addEventListener("change", onChange, true);

  // ---- Klick-Puls (Tango-Stil): blaues Aufleuchten um das erfasste Element. ----
  let lastClickPx = null;
  function showCapturePulse() {
    if (!lastClickPx) return;
    // Einmal verbrauchen: das Panel stoesst den Puls an ALLE Frames des Tabs an (all_frames,
    // Welle 48) — nur der Frame, der zuletzt einen Schritt erfasst hat, soll aufleuchten.
    const px = lastClickPx;
    lastClickPx = null;
    const pad = 4;
    const el = document.createElement("div");
    const hasRect = px.width > 2 && px.height > 2;
    const st = el.style;
    st.position = "fixed";
    st.zIndex = "2147483647";
    st.pointerEvents = "none";
    st.border = "3px solid #ef6a4e";
    st.boxShadow = "0 0 0 4px rgba(239,106,78,0.25)";
    st.borderRadius = hasRect ? "10px" : "50%";
    if (hasRect) {
      st.left = px.left - pad + "px";
      st.top = px.top - pad + "px";
      st.width = px.width + pad * 2 + "px";
      st.height = px.height + pad * 2 + "px";
    } else {
      // Fallback ohne Element-Box: kleiner Kreis am Klickpunkt.
      st.left = px.cx - 16 + "px";
      st.top = px.cy - 16 + "px";
      st.width = "32px";
      st.height = "32px";
    }
    (document.documentElement || document.body).appendChild(el);
    try {
      el.animate(
        [
          { opacity: 0.9, transform: "scale(0.97)" },
          { opacity: 1, transform: "scale(1.03)", offset: 0.35 },
          { opacity: 0, transform: "scale(1.0)" },
        ],
        { duration: 650, easing: "ease-out" }
      ).onfinish = () => el.remove();
    } catch (err) {
      setTimeout(() => el.remove(), 650);
    }
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.type === "steply-guide-captured" && recording && mode === "guide") {
      // all_frames (Welle 48): die Nachricht erreicht JEDEN Frame des Tabs. Pulsen darf nur der
      // Frame, der den Schritt gerade erfasst hat — lastClickPx wird darum nach dem Puls
      // VERBRAUCHT (sonst pulste ein anderer Frame spaeter mit einem alten Rechteck).
      showCapturePulse();
      lastClickPx = null;
    }
  });

  // "Inhalt aktualisiert"-Signal der Seitenleiste (nach erfolgreichem Upload) in die
  // Seite weiterreichen - ein offener Builder/die Bibliothek laedt dann ohne F5 nach
  // (die App lauscht via ContentUpdatedRefresh; auf fremden Seiten verpufft es einfach).
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "steply-content-updated") return;
    if (!IS_TOP) return; // App-Seiten-Signal nur im Hauptfenster (Welle 48, all_frames)
    try {
      window.postMessage(
        { __steply: true, type: "steply-content-updated" },
        location.origin
      );
    } catch (err) {
      /* egal */
    }
  });

  // ============================================================================
  // FRAME-ZUSTAENDIGKEIT + INTERAKTION (Welle 48)
  //
  // Seit all_frames laeuft dieses Script in JEDEM Frame eines Tabs, und chrome.tabs.sendMessage
  // erreicht ALLE Frames. Damit ein Schritt genau EINMAL ausgefuehrt/gezeigt wird:
  //   • Schritt MIT interaction.frame.url → nur der iframe, dessen origin+pathname passt.
  //   • Schritt OHNE frame                → nur das Hauptfenster (IS_TOP).
  // Nachrichten mit Antwort (has-password, eval-condition, refetch, file-*) beantwortet NUR das
  // Hauptfenster; iframes geben false zurueck (kein sendResponse) — Chrome nimmt dann die
  // Antwort des Hauptfensters.
  // ============================================================================
  function frameNormPath(p) {
    const s = String(p || "").replace(/\/+$/, "");
    return s || "/";
  }
  function frameUrlIsThisFrame(url) {
    try {
      // about:blank/about:srcdoc-Frames (Rich-Text-Editoren wie TinyMCE) haben keine Herkunft.
      if (/^about:/i.test(url)) return String(location.href || "").split(/[?#]/)[0] === url;
      const u = new URL(url);
      return (
        u.origin.toLowerCase() === String(location.origin).toLowerCase() &&
        frameNormPath(u.pathname) === frameNormPath(location.pathname)
      );
    } catch (err) {
      return false;
    }
  }
  function interactionOf(step) {
    const it = step && step.interaction;
    return it && typeof it === "object" && !Array.isArray(it) ? it : null;
  }
  function stepIsForThisFrame(step) {
    const it = interactionOf(step);
    const url = it && it.frame && typeof it.frame.url === "string" ? it.frame.url : "";
    if (!url) return IS_TOP;
    if (IS_TOP) return false;
    if (!frameUrlIsThisFrame(url)) return false;
    // Gleichartige Geschwister-Frames: nur der mit derselben Nummer (s. frameNth).
    const nth = it.frame.nth;
    return typeof nth === "number" ? frameNth() === nth : true;
  }

  // Tastenkuerzel „Ctrl+Shift+S" → { key, code, keyCode, ctrlKey, altKey, shiftKey, metaKey }.
  // Aufgenommen wird die neutrale Form (Ctrl/Alt/Shift/Meta+Taste); deutsche Namen werden toleriert.
  const KEY_MODS = {
    ctrl: "ctrlKey",
    control: "ctrlKey",
    strg: "ctrlKey",
    alt: "altKey",
    altgraph: "altKey",
    shift: "shiftKey",
    umschalt: "shiftKey",
    meta: "metaKey",
    cmd: "metaKey",
    command: "metaKey",
    win: "metaKey",
    os: "metaKey",
  };
  const KEY_NAMES = {
    esc: "Escape",
    escape: "Escape",
    del: "Delete",
    delete: "Delete",
    entf: "Delete",
    backspace: "Backspace",
    space: " ",
    spacebar: " ",
    leertaste: " ",
    enter: "Enter",
    return: "Enter",
    tab: "Tab",
    arrowup: "ArrowUp",
    arrowdown: "ArrowDown",
    arrowleft: "ArrowLeft",
    arrowright: "ArrowRight",
    home: "Home",
    pos1: "Home",
    end: "End",
    ende: "End",
    pageup: "PageUp",
    pagedown: "PageDown",
    insert: "Insert",
    einfg: "Insert",
  };
  const KEY_CODES = {
    Enter: 13,
    Escape: 27,
    Tab: 9,
    Delete: 46,
    Backspace: 8,
    " ": 32,
    ArrowLeft: 37,
    ArrowUp: 38,
    ArrowRight: 39,
    ArrowDown: 40,
    Home: 36,
    End: 35,
    PageUp: 33,
    PageDown: 34,
    Insert: 45,
  };
  function parseKeyCombo(combo) {
    const raw = String(combo || "").trim();
    if (!raw) return null;
    const out = { key: "", code: "", keyCode: 0, ctrlKey: false, altKey: false, shiftKey: false, metaKey: false };
    const parts = raw.split("+");
    let keyTok = "";
    for (let i = 0; i < parts.length; i++) {
      const p = parts[i].trim();
      if (!p) {
        if (i === parts.length - 1) keyTok = "+"; // „Ctrl++"
        continue;
      }
      const mod = KEY_MODS[p.toLowerCase()];
      if (mod && i < parts.length - 1) out[mod] = true;
      else keyTok = p;
    }
    if (!keyTok) return null;
    if (keyTok.length === 1) {
      const up = keyTok.toUpperCase();
      out.key = out.shiftKey ? up : keyTok.toLowerCase();
      if (/[A-Z]/.test(up)) {
        out.code = "Key" + up;
        out.keyCode = up.charCodeAt(0);
      } else if (/[0-9]/.test(up)) {
        out.code = "Digit" + up;
        out.keyCode = up.charCodeAt(0);
      }
    } else {
      const fn = /^f([1-9]|1[0-2])$/i.exec(keyTok);
      if (fn) {
        out.key = out.code = "F" + fn[1];
        out.keyCode = 111 + Number(fn[1]);
      } else {
        out.key = KEY_NAMES[keyTok.toLowerCase()] || keyTok;
        out.code = out.key === " " ? "Space" : out.key;
        out.keyCode = KEY_CODES[out.key] || 0;
      }
    }
    return out;
  }
  // Passt ein echtes keydown zur Kombination? Modifier exakt, Taste per key ODER code.
  function keyComboMatches(ev, combo) {
    if (!ev || !combo) return false;
    if (!!ev.ctrlKey !== combo.ctrlKey || !!ev.altKey !== combo.altKey || !!ev.metaKey !== combo.metaKey) {
      return false;
    }
    // Shift nur bei Nicht-Buchstaben-Tasten streng (bei Buchstaben steckt es auch im key).
    if (combo.key.length !== 1 && !!ev.shiftKey !== combo.shiftKey) return false;
    const k = String(ev.key || "");
    if (k && k.toLowerCase() === combo.key.toLowerCase()) return true;
    return !!(combo.code && ev.code === combo.code);
  }
  // Deutsche Anzeige fuer den Hinweis im Overlay („Strg+S").
  function keyDisplayDe(combo) {
    const map = {
      ctrl: "Strg",
      control: "Strg",
      shift: "Umschalt",
      meta: "Cmd",
      escape: "Esc",
      delete: "Entf",
      space: "Leertaste",
    };
    return String(combo || "")
      .split("+")
      .map((p) => {
        const t = p.trim();
        return map[t.toLowerCase()] || (t.length === 1 ? t.toUpperCase() : t);
      })
      .join("+");
  }
  function interactionLabel(text) {
    const t = String(text || "").replace(/\s+/g, " ").trim();
    return t.length > 40 ? t.slice(0, 39) + "…" : t;
  }

  // ============================================================================
  // LIVE-FUEHRUNG (Welle 31): Overlay auf der ECHTEN Seite (Tango/WalkMe-Prinzip).
  //
  // Das Panel schickt pro Schritt {type:"steply-guide-show", step:{selector,title,index,
  // total}}. Wir loesen das Element via SteplyGuideResolve.resolveSelector auf (SPA-
  // tolerant: bis ~1,5 s in Intervallen nachversuchen), zeichnen einen pulsierenden
  // Koralle-Rahmen (#ef6a4e) + ein Schritt-Badge „3/12", scrollen das Element in die Mitte
  // und lassen die Markierung Scroll/Resize folgen. Ein pointerdown auf dem Ziel (Capture)
  // meldet {type:"steply-guide-advance"}. Nicht gefunden -> {type:"steply-guide-status",
  // found:false}. „steply-guide-hide" raeumt Overlay + Listener restlos auf. Das Overlay
  // selbst ist pointer-events:none -> Klicks gehen an die echte Seite. Stile isoliert per
  // Inline-Style (wie showCapturePulse), Puls ueber die Web-Animations-API (kein globales CSS).
  // Der Installations-Guard oben sorgt dafuer, dass dieser Block pro Dokument nur EINMAL laeuft.
  // ============================================================================
  const GUIDE_OVERLAY_ID = "__steply-guide-overlay";
  let guideOverlayEl = null; // Container (Rahmen + Badge)
  let guideFrameEl = null; // pulsierender Rahmen
  let guideBadgeEl = null; // Schritt-Pille „3/12"
  let guideTargetEl = null; // aufgeloestes Ziel-Element
  // Element-Suche (Welle 33, Fix 3): MutationObserver + Fallback-Tick + Timeout statt starrem
  // Kurz-Polling. Alle drei werden von guideStopSearch() zentral abgeraeumt.
  let guideSearchObserver = null;
  let guideSearchTick = null;
  let guideSearchTimeout = null;
  let guideRafPending = false; // Reposition-Drossel (requestAnimationFrame)
  let guideAdvanceModeCur = "click"; // wie das Ziel „weiter" ausloest (s. guideAdvanceMode)
  let guideFieldListeners = null; // { el, onChange, onBlur, onKeydown } fuer Eingabe-Ziele
  // Welle 48: Varianten-Listener (contextmenu/dblclick/drop/keydown/Zeiger-Ziehen) auf document —
  // [{ type, fn }], restlos in guideCleanup entfernt. guideHoverPhase: Overlay zeigt gerade den
  // HOVER-Ausloeser (Menue noch zu) statt des eigentlichen Ziels.
  let guideVariantListeners = [];
  let guideHoverPhase = false;
  let guideAdvanced = false; // Doppel-„weiter"-Schutz (Enter + blur / mehrere pointerdown)
  let guideTargetLost = false; // Ziel verschwand (SPA/0x0) -> Overlay versteckt, found:false EINMAL
  // Stille Wiederaufnahme (Hotfix 06.07.): SPAs/PPR ersetzen oder verstecken Knoten waehrend
  // Hydration/Streaming kurzzeitig. Bei Ziel-Verlust NICHT sofort aufgeben, sondern den
  // zuletzt gezeigten Schritt einmal komplett neu aufloesen (voller Suchlauf inkl. Ersatz-Knoten).
  let guideCurrentStep = null;
  let guideReacquireTimer = null;
  // Selbstschutz (Welle 33, Fix 2b): laeuft ein Overlay, aber kommt >60s kein show/ping mehr
  // (Panel hart geschlossen, Port-Hide verpasst), raeumt das Content-Script SELBST ab.
  let guideLastSignalAt = 0;
  let guideWatchdog = null;
  const GUIDE_SIGNAL_MAX_IDLE = 60000;

  // Genau EINMAL „weiter" pro Schritt melden (Enter + folgendes blur duerfen NICHT zwei
  // Schritte ueberspringen). Der Reset passiert beim naechsten steply-guide-show.
  function guideAdvance() {
    if (guideAdvanced) return;
    guideAdvanced = true;
    try {
      chrome.runtime.sendMessage({ type: "steply-guide-advance" });
    } catch (err) {
      /* Panel evtl. geschlossen - egal */
    }
  }

  // Wie ein aufgeloestes Ziel „weiter" schaltet:
  //   "click"  -> pointerdown (Buttons/Links/normale Klick-Ziele; Bestand).
  //   "text"   -> Enter im Feld ODER Verlassen (blur/change) mit NICHT-leerem Wert
  //               (input[text], textarea, contenteditable, role=textbox/searchbox/combobox).
  //   "toggle" -> change (Checkbox/Radio).
  //   "select" -> change (natives <select>).
  // Ein Klick IN ein Textfeld darf NICHT weiterschalten — sonst kommt man nie zum Tippen.
  function guideAdvanceMode(el) {
    if (!el || el.nodeType !== 1) return "click";
    const tag = (el.tagName || "").toLowerCase();
    const type = ((el.getAttribute && el.getAttribute("type")) || "").toLowerCase();
    if (tag === "select") return "select";
    if (tag === "textarea") return "text";
    if (tag === "input") {
      if (/^(checkbox|radio)$/.test(type)) return "toggle";
      if (/^(button|submit|reset|image|file|range|color)$/.test(type)) return "click";
      return "text"; // text/email/search/password/number/tel/url/date/...
    }
    if (el.isContentEditable === true) return "text";
    const role = ((el.getAttribute && el.getAttribute("role")) || "").toLowerCase();
    if (role === "textbox" || role === "searchbox" || role === "combobox") return "text";
    return "click";
  }

  // Hat ein Textfeld einen NICHT-leeren Wert? (contenteditable ueber textContent.)
  function guideFieldHasValue(el) {
    try {
      if (el.isContentEditable === true) return !!String(el.textContent || "").trim();
      return !!String(el.value == null ? "" : el.value).trim();
    } catch (err) {
      return false;
    }
  }

  // Fuer Eingabe-Ziele die passenden Listener setzen (Klick-Ziele laufen ueber pointerdown).
  function attachGuideFieldListeners(el, mode) {
    guideFieldListeners = null;
    if (mode === "click") return;
    const onChange = () => {
      if (mode === "toggle" || mode === "select") {
        guideAdvance();
      } else if (mode === "text" && guideFieldHasValue(el)) {
        guideAdvance();
      }
    };
    const onBlur = () => {
      if (mode === "text" && guideFieldHasValue(el)) guideAdvance();
    };
    const onKeydown = (e) => {
      if ((mode === "text" || mode === "select") && (e.key === "Enter" || e.keyCode === 13)) {
        guideAdvance();
      }
    };
    // Natives <select> (Hotfix 06.07.): Waehlt man die BEREITS eingestellte Option erneut,
    // feuert KEIN change (Wert unveraendert) — der Schritt schaltete dann nie weiter.
    // Chrome dispatcht beim Waehlen einer Option (auch derselben) einen click auf dem
    // <select> OHNE frisches eigenes pointerdown (das ging ans native Popup). Ein click
    // ohne kurz vorangegangenes pointerdown = Option gewaehlt -> weiter. Auf-/Zuklappen
    // (pointerdown + click direkt auf dem Element) schaltet NICHT weiter. Feuert Chrome
    // den click mal nicht, bleibt es beim heutigen Verhalten (change/Enter) — kein Risiko.
    let lastDownAt = 0;
    const onDown = () => {
      lastDownAt = Date.now();
    };
    const onClick = () => {
      if (mode === "select" && Date.now() - lastDownAt > 150) guideAdvance();
    };
    try {
      el.addEventListener("change", onChange, true);
      if (mode === "text") {
        el.addEventListener("blur", onBlur, true);
        el.addEventListener("keydown", onKeydown, true);
      }
      if (mode === "select") {
        el.addEventListener("keydown", onKeydown, true);
        el.addEventListener("pointerdown", onDown, true);
        el.addEventListener("click", onClick, true);
      }
      guideFieldListeners = { el, onChange, onBlur, onKeydown, onDown, onClick };
    } catch (err) {
      guideFieldListeners = null;
    }
  }

  // Laufende Element-Suche (Observer + Tick + Timeout) restlos stoppen.
  function guideStopSearch() {
    if (guideSearchObserver) {
      try {
        guideSearchObserver.disconnect();
      } catch (err) {
        /* egal */
      }
      guideSearchObserver = null;
    }
    if (guideSearchTick) {
      clearInterval(guideSearchTick);
      guideSearchTick = null;
    }
    if (guideSearchTimeout) {
      clearTimeout(guideSearchTimeout);
      guideSearchTimeout = null;
    }
  }

  function guideStopWatchdog() {
    if (guideWatchdog) {
      clearInterval(guideWatchdog);
      guideWatchdog = null;
    }
  }

  // Zombie-Overlays ENTFERNEN (Hotfix 06.07.): Ein Extension-Reload laesst alte content-
  // Script-Instanzen verwaist in offenen Tabs zurueck — deren Overlay-DOM (Rahmen + Badge)
  // klebt sonst fuer immer auf der Seite (Richards „Duplikat, das beim Scrollen wandert").
  // Wir raeumen deshalb ALLE Elemente mit unserer Overlay-ID ab, nicht nur das eigene.
  // (querySelectorAll findet auch mehrfach vergebene IDs.)
  function guideRemoveStrays() {
    try {
      document.querySelectorAll('[id="' + GUIDE_OVERLAY_ID + '"]').forEach((n) => {
        if (n !== guideOverlayEl) {
          try {
            n.remove();
          } catch (err) {
            /* egal */
          }
        }
      });
    } catch (err) {
      /* egal */
    }
  }

  function guideCleanup() {
    guideStopSearch();
    guideStopWatchdog();
    guideTargetLost = false;
    if (guideReacquireTimer) {
      clearTimeout(guideReacquireTimer);
      guideReacquireTimer = null;
    }
    document.removeEventListener("pointerdown", onGuidePointerDown, true);
    guideRemoveVariantListeners();
    guideHoverPhase = false;
    window.removeEventListener("scroll", guideReposition, true);
    window.removeEventListener("resize", guideReposition, true);
    if (guideFieldListeners) {
      const { el, onChange, onBlur, onKeydown, onDown, onClick } = guideFieldListeners;
      try {
        el.removeEventListener("change", onChange, true);
        el.removeEventListener("blur", onBlur, true);
        el.removeEventListener("keydown", onKeydown, true);
        if (onDown) el.removeEventListener("pointerdown", onDown, true);
        if (onClick) el.removeEventListener("click", onClick, true);
      } catch (err) {
        /* egal */
      }
      guideFieldListeners = null;
    }
    if (guideOverlayEl && guideOverlayEl.parentNode) {
      try {
        guideOverlayEl.parentNode.removeChild(guideOverlayEl);
      } catch (err) {
        /* egal */
      }
    }
    guideOverlayEl = null;
    guideFrameEl = null;
    guideBadgeEl = null;
    guideTargetEl = null;
    guideRemoveStrays();
  }

  // pointerdown auf dem Ziel (oder einem Kind) -> „weiter" — NUR fuer Klick-Ziele. Textfelder/
  // Checkbox/Select schalten ueber ihre eigenen Listener (s. attachGuideFieldListeners) weiter.
  // Capture-Phase, damit es auch feuert, wenn die Seite stopPropagation nutzt bzw. navigiert.
  function onGuidePointerDown(event) {
    // Welle 48: im Hover-Schritt schaltet der Ausloeser NIE weiter; Varianten (Rechtsklick,
    // Doppelklick, Ziehen, Kuerzel) haben eigene Listener (guideAttachVariantListeners).
    if (!guideTargetEl || guideAdvanceModeCur !== "click" || guideHoverPhase) return;
    const t = event.target;
    if (t === guideTargetEl || (guideTargetEl.contains && guideTargetEl.contains(t))) {
      guideAdvance();
    }
  }

  // Rahmen + Badge zeigen/verstecken (Welle 33, Fix 2c): verschwindet das Ziel, darf das
  // Badge nicht bei 0,0 kleben — dann verstecken wir das Overlay komplett.
  function guideSetOverlayVisible(on) {
    if (guideFrameEl) guideFrameEl.style.display = on ? "" : "none";
    if (guideBadgeEl) guideBadgeEl.style.display = on ? "" : "none";
  }

  // Rahmen + Badge an die aktuelle Element-Position setzen (gedrosselt via rAF).
  function guideReposition() {
    if (guideRafPending) return;
    guideRafPending = true;
    requestAnimationFrame(() => {
      guideRafPending = false;
      if (!guideTargetEl || !guideFrameEl) return;
      let r;
      try {
        r = guideTargetEl.getBoundingClientRect();
      } catch (err) {
        r = null;
      }
      // Ziel weg (aus dem DOM entfernt / SPA-Umbau) oder unsichtbar (0×0)? Overlay NICHT bei
      // 0,0 kleben lassen — verstecken und EINMALIG found:false melden (kein Spam pro Frame).
      // Kommt das Element zurueck, zeigt das naechste Reposition/Show es wieder an.
      const lost = !guideTargetEl.isConnected || !r || (r.width <= 0 && r.height <= 0);
      if (lost) {
        guideSetOverlayVisible(false);
        if (!guideTargetLost) {
          guideTargetLost = true;
          // NICHT sofort aufgeben (Hotfix 06.07.): erst STILL komplett neu aufloesen —
          // der volle Suchlauf findet auch ERSETZTE Knoten (React/PPR) und meldet erst
          // nach seinem Timeout found:false. Erfolg -> guideAttach meldet found:true,
          // das Panel verlaesst den Fallback wieder.
          if (guideCurrentStep && !guideReacquireTimer) {
            guideReacquireTimer = setTimeout(() => {
              guideReacquireTimer = null;
              if (guideCurrentStep) {
                showGuideStep(guideCurrentStep);
                guideStartWatchdog();
              }
            }, 300);
          } else if (!guideCurrentStep) {
            try {
              chrome.runtime.sendMessage({ type: "steply-guide-status", found: false, reason: "target-gone" });
            } catch (err) {
              /* Panel evtl. zu - egal */
            }
          }
        }
        return;
      }
      if (guideTargetLost) {
        guideTargetLost = false;
        guideSetOverlayVisible(true);
      }
      const pad = 4;
      const left = r.left - pad;
      const top = r.top - pad;
      const fs = guideFrameEl.style;
      fs.left = left + "px";
      fs.top = top + "px";
      fs.width = r.width + pad * 2 + "px";
      fs.height = r.height + pad * 2 + "px";
      if (guideBadgeEl) {
        let badgeTop = top - 25;
        if (badgeTop < 2) badgeTop = top + 2; // oben kein Platz -> nach innen
        guideBadgeEl.style.left = Math.max(2, left) + "px";
        guideBadgeEl.style.top = badgeTop + "px";
      }
    });
  }

  function buildGuideOverlay(step, hint) {
    const container = document.createElement("div");
    container.id = GUIDE_OVERLAY_ID;
    const cs = container.style;
    cs.position = "fixed";
    cs.zIndex = "2147483647";
    cs.pointerEvents = "none";
    cs.left = "0";
    cs.top = "0";
    cs.margin = "0";
    cs.padding = "0";
    cs.border = "0";
    cs.background = "transparent";

    const frame = document.createElement("div");
    const fst = frame.style;
    fst.position = "fixed";
    fst.boxSizing = "border-box";
    fst.border = "3px solid #ef6a4e";
    fst.borderRadius = "10px";
    fst.pointerEvents = "none";
    fst.transformOrigin = "center center";
    // Ruhe-Zustand des Glows (der Puls/Blitz animiert darauf auf).
    fst.boxShadow = GUIDE_GLOW_BASE;
    container.appendChild(frame);

    const badge = document.createElement("div");
    const bst = badge.style;
    bst.position = "fixed";
    bst.pointerEvents = "none";
    bst.background = "#ef6a4e";
    bst.color = "#fff";
    // Groesser + kontrastreicher (Welle 32, Punkt B): kraeftigere Schrift, weisser Rahmen +
    // dunkler Schlagschatten, damit die Pille auf jedem Untergrund lesbar bleibt.
    bst.font = "800 13px/1.35 system-ui,-apple-system,'Segoe UI',Roboto,sans-serif";
    bst.padding = "3px 9px";
    bst.borderRadius = "999px";
    bst.boxShadow = "0 0 0 2px rgba(255,255,255,0.85), 0 2px 8px rgba(0,0,0,0.35)";
    bst.whiteSpace = "nowrap";
    bst.letterSpacing = "0.02em";
    // Welle 48: kurzer Bedien-Hinweis hinter der Schritt-Nummer („3/12 · Rechtsklick").
    badge.textContent = (step.index || 1) + "/" + (step.total || 1) + (hint ? " · " + hint : "");
    container.appendChild(badge);

    (document.documentElement || document.body).appendChild(container);
    guideOverlayEl = container;
    guideFrameEl = frame;
    guideBadgeEl = badge;

    // ERSCHEINEN: kurzer „Hingucker" (Aufziehen 1.15 -> 1.0 + kraeftiger Glow-Blitz), danach
    // ruhiger Dauer-Puls (~1,2s). Alles ueber die Web-Animations-API — kein globales CSS.
    startGuideAppear(frame);
  }

  // Ruhe-Glow (Basis) und der kraeftige „Blitz"-Glow (Erscheinen/Puls-Hochpunkt).
  const GUIDE_GLOW_BASE =
    "0 0 0 3px rgba(239,106,78,0.55), 0 0 15px 3px rgba(239,106,78,0.35)";
  const GUIDE_GLOW_FLASH =
    "0 0 0 6px rgba(239,106,78,0.6), 0 0 34px 12px rgba(239,106,78,0.5)";
  const GUIDE_GLOW_DIM =
    "0 0 0 8px rgba(239,106,78,0.12), 0 0 26px 9px rgba(239,106,78,0.14)";

  // Ruhiger Dauer-Puls (~1,2s): Glow-Ring atmet zwischen kraeftig und weich. Bewusst NICHT
  // epilepsie-artig (weiche ease-in-out-Rampe, moderater Frequenzbereich).
  function startGuidePulse(frame) {
    try {
      frame.animate(
        [
          { boxShadow: GUIDE_GLOW_BASE },
          { boxShadow: GUIDE_GLOW_DIM },
          { boxShadow: GUIDE_GLOW_BASE },
        ],
        { duration: 1200, iterations: Infinity, easing: "ease-in-out" }
      );
    } catch (err) {
      /* ohne Animation trotzdem sichtbar (statischer Basis-Glow bleibt) */
    }
  }

  // „Hingucker" beim Erscheinen: einmaliges Aufziehen (Zoom 1.15 -> 1.0) + Glow-Blitz, dann
  // in den Dauer-Puls uebergehen. Faellt bei fehlender Animations-API sofort auf den Puls.
  function startGuideAppear(frame) {
    let anim = null;
    try {
      anim = frame.animate(
        [
          { transform: "scale(1.15)", boxShadow: GUIDE_GLOW_FLASH },
          { transform: "scale(0.98)", boxShadow: GUIDE_GLOW_BASE, offset: 0.72 },
          { transform: "scale(1)", boxShadow: GUIDE_GLOW_BASE },
        ],
        { duration: 520, easing: "cubic-bezier(0.22,1,0.36,1)" }
      );
    } catch (err) {
      anim = null;
    }
    if (anim) {
      anim.onfinish = () => startGuidePulse(frame);
      anim.oncancel = () => {};
    } else {
      startGuidePulse(frame);
    }
  }

  // ── Welle 48: erweiterte Interaktion in der Fuehrung ──────────────────────────────────
  // Welche „weiter"-Erkennung braucht der Schritt? null = die bisherige (Klick/Feld).
  function guideVariantMode(step) {
    const it = interactionOf(step);
    const v = it && it.variant;
    if (v === "right" || v === "double") return v;
    if (v === "drag" && it.drop) return "drag";
    if (v === "key" && parseKeyCombo(it.key)) return "key";
    return null;
  }

  // Kurzer Hinweis im Badge. Ohne Besonderheit → "" (Badge bleibt „3/12" wie bisher).
  function guideHintFor(step) {
    const it = interactionOf(step);
    if (!it) return "";
    if (it.variant === "right") return "Rechtsklick";
    if (it.variant === "double") return "Doppelklick";
    if (it.variant === "drag") {
      const d = interactionLabel(it.dropLabel || (it.drop && it.drop.text));
      return d ? "Ziehen auf „" + d + "“" : "Ziehen";
    }
    if (it.variant === "key" && it.key) return keyDisplayDe(it.key) + " drücken";
    if (it.enter) return "Eingeben + Enter";
    return "";
  }
  function guideHoverHint(step) {
    const it = interactionOf(step);
    const h = interactionLabel(it && (it.hoverLabel || (it.hover && it.hover.text)));
    return h ? "Mit der Maus über „" + h + "“ fahren" : "Mit der Maus hierüber fahren";
  }

  function guideRemoveVariantListeners() {
    for (const l of guideVariantListeners) {
      try {
        document.removeEventListener(l.type, l.fn, true);
      } catch (err) {
        /* egal */
      }
    }
    guideVariantListeners = [];
  }
  function guideOnDoc(type, fn) {
    document.addEventListener(type, fn, true);
    guideVariantListeners.push({ type: type, fn: fn });
  }
  function guideInside(root, node) {
    return !!(root && node && (root === node || (root.contains && root.contains(node))));
  }

  // „weiter" genau beim passenden Ereignis: contextmenu (Rechtsklick), dblclick (Doppelklick),
  // drop auf das Ablage-Ziel bzw. Zeiger-Ziehen dorthin (Ziehen), keydown mit der Kombination
  // (Kuerzel). Capture-Phase auf document — feuert auch, wenn die Seite stopPropagation nutzt.
  function guideAttachVariantListeners(step, variantMode) {
    guideRemoveVariantListeners();
    const it = interactionOf(step) || {};
    if (variantMode === "right") {
      guideOnDoc("contextmenu", (e) => {
        if (guideInside(guideTargetEl, e.target)) guideAdvance();
      });
      return;
    }
    if (variantMode === "double") {
      guideOnDoc("dblclick", (e) => {
        if (guideInside(guideTargetEl, e.target)) guideAdvance();
      });
      return;
    }
    if (variantMode === "key") {
      const combo = parseKeyCombo(it.key);
      guideOnDoc("keydown", (e) => {
        if (keyComboMatches(e, combo)) guideAdvance();
      });
      return;
    }
    if (variantMode === "drag") {
      const resolver =
        (globalThis.SteplyGuideResolve && globalThis.SteplyGuideResolve.resolveSelector) || null;
      const dropEl = () => {
        try {
          const r = resolver ? resolver(document, it.drop, RESOLVE_OPTS) : null;
          return r && r.el ? r.el : null;
        } catch (err) {
          return null;
        }
      };
      let started = false;
      let downAt = null;
      guideOnDoc("dragstart", (e) => {
        if (guideInside(guideTargetEl, e.target)) started = true;
      });
      guideOnDoc("drop", (e) => {
        if (!started) return;
        const d = dropEl();
        if (!d || guideInside(d, e.target)) guideAdvance();
      });
      // Zeiger-basiertes Ziehen (Bibliotheken ohne HTML5-DnD): gedrueckt auf dem Element,
      // losgelassen deutlich entfernt UEBER dem Ablage-Ziel.
      guideOnDoc("pointerdown", (e) => {
        downAt = guideInside(guideTargetEl, e.target) ? { x: e.clientX, y: e.clientY } : null;
      });
      guideOnDoc("pointerup", (e) => {
        if (!downAt) return;
        const moved = Math.abs(e.clientX - downAt.x) + Math.abs(e.clientY - downAt.y);
        downAt = null;
        if (moved < 24) return;
        const d = dropEl();
        let under = null;
        try {
          under = document.elementFromPoint(e.clientX, e.clientY);
        } catch (err) {
          under = null;
        }
        if (d && guideInside(d, under)) guideAdvance();
      });
    }
  }

  // HOVER-Phase: das eigentliche Ziel ist noch versteckt (Menue zu) → den Ausloeser markieren
  // mit „Mit der Maus über „H“ fahren". KEIN „weiter" von hier; die Suche nach dem Ziel laeuft
  // weiter (showGuideStep) und wechselt, sobald es sichtbar ist.
  function guideAttachHover(el, step) {
    guideTargetEl = el;
    guideHoverPhase = true;
    guideAdvanceModeCur = "hover";
    buildGuideOverlay(step, guideHoverHint(step));
    guideReposition();
    window.addEventListener("scroll", guideReposition, true);
    window.addEventListener("resize", guideReposition, true);
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
    } catch (err) {
      /* egal */
    }
    setTimeout(guideReposition, 320);
    try {
      chrome.runtime.sendMessage({ type: "steply-guide-status", found: true, phase: "hover" });
    } catch (err) {
      /* egal */
    }
  }

  // Ziel gefunden: Overlay bauen, verankern, in Sicht scrollen, Listener setzen.
  function guideAttach(el, step) {
    guideTargetEl = el;
    // Welle 48: Rechtsklick/Doppelklick/Ziehen/Kuerzel schalten ueber IHR Ereignis weiter.
    const variantMode = guideVariantMode(step);
    guideAdvanceModeCur = variantMode || guideAdvanceMode(el);
    buildGuideOverlay(step, guideHintFor(step));
    guideReposition();
    window.addEventListener("scroll", guideReposition, true);
    window.addEventListener("resize", guideReposition, true);
    document.addEventListener("pointerdown", onGuidePointerDown, true);
    // Eingabe-Ziele (Textfeld/Checkbox/Select) schalten NICHT bei pointerdown weiter, sondern
    // erst nach Eingabe (Enter/blur/change) — s. attachGuideFieldListeners.
    if (variantMode) guideAttachVariantListeners(step, variantMode);
    else attachGuideFieldListeners(el, guideAdvanceModeCur);
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
    } catch (err) {
      try {
        el.scrollIntoView();
      } catch (e) {
        /* egal */
      }
    }
    // Nach dem (smooth) Scrollen neu positionieren - die Box hat sich bewegt.
    setTimeout(guideReposition, 320);
    try {
      chrome.runtime.sendMessage({ type: "steply-guide-status", found: true });
    } catch (err) {
      /* egal */
    }
  }

  // „Signal" (show/ping) merken + Watchdog starten (Selbstschutz, Welle 33, Fix 2b).
  function guideNoteSignal() {
    guideLastSignalAt = Date.now();
  }
  function guideStartWatchdog() {
    if (guideWatchdog) return;
    guideWatchdog = setInterval(() => {
      if (!guideOverlayEl) {
        guideStopWatchdog(); // kein Overlay -> Watchdog nicht noetig
        return;
      }
      if (Date.now() - guideLastSignalAt > GUIDE_SIGNAL_MAX_IDLE) {
        // >60s kein show/ping -> Panel vermutlich hart weg, Overlay selbst abraeumen.
        guideCleanup();
        return;
      }
      // Ziel-Verlust auch OHNE Scroll/Resize erkennen (SPA entfernt das Element still).
      guideReposition();
    }, 10000);
  }

  // Sichtbarkeits-Praedikat fuer den Resolver (Welle 45): SICHTBARE ELEMENTE BEVORZUGEN. Wir
  // injizieren diese Funktion in resolveSelector(document, sel, { isVisible }), damit Stufe 2/3
  // einen sichtbaren Kandidaten waehlen, statt an einem unsichtbaren 0×0-Duplikat (z. B.
  // eingeklapptes Mobil-Menue) haengen zu bleiben — Richards „Anmelden"-Fall. Der Resolver bleibt
  // PUR (er ruft NIE selbst getBoundingClientRect); dieselbe 0×0-Regel wie die 0×0-Nachpruefung im
  // Aufrufer, die als Guertel-und-Hosentraeger BESTEHEN bleibt.
  function resolveElIsVisible(el) {
    try {
      var r = el && el.getBoundingClientRect ? el.getBoundingClientRect() : null;
      return !!(r && r.width > 0 && r.height > 0);
    } catch (err) {
      return false;
    }
  }
  var RESOLVE_OPTS = { isVisible: resolveElIsVisible };

  const GUIDE_HOVER_MAX_WAIT = 30000; // Hover-Phase: 30 s, bis der Menuepunkt erscheint

  // Einen Schritt anzeigen: Element aufloesen, dann bis ~5s SPA-tolerant nachversuchen
  // (MutationObserver + 250ms-Fallback-Tick), sonst found:false + Grund melden (Welle 33, Fix 3).
  function showGuideStep(step) {
    guideCleanup(); // vorherigen Zustand + laufende Suche restlos abbauen
    guideAdvanced = false; // „weiter"-Schutz je Schritt zuruecksetzen
    guideTargetLost = false;
    guideCurrentStep = step || null; // fuer die stille Wiederaufnahme nach Ziel-Verlust
    const resolver =
      (globalThis.SteplyGuideResolve && globalThis.SteplyGuideResolve.resolveSelector) || null;
    if (!step || !step.selector || !resolver) {
      try {
        chrome.runtime.sendMessage({ type: "steply-guide-status", found: false, reason: "no-selector" });
      } catch (err) {
        /* egal */
      }
      return;
    }

    const MAX_WAIT = 5000;
    let lastReason = "timeout"; // wenn nie ein definitiver Grund kam: schlicht „nicht rechtzeitig"
    let done = false;
    // Welle 48 (Hover-Menue): ist das Ziel (noch) nicht sichtbar, aber ein Hover-Ausloeser
    // bekannt, markieren wir ERST den Ausloeser („Mit der Maus über „H“ fahren") und suchen
    // OHNE Zeitlimit weiter — sobald der Mensch das Menue oeffnet, wechselt das Overlay aufs Ziel.
    const hoverSel = (interactionOf(step) || {}).hover || null;
    let hoverShown = false;
    const tryHover = () => {
      let h = null;
      try {
        h = resolver(document, hoverSel, RESOLVE_OPTS);
      } catch (err) {
        h = null;
      }
      if (!h || !h.el || !resolveElIsVisible(h.el)) return;
      hoverShown = true;
      // Der Mensch braucht Zeit fuers Menue — Frist deutlich laenger, aber NICHT endlos: fehlt
      // der Menuepunkt (umbenannt/entfernt), meldet die Fuehrung ehrlich „nicht gefunden" und
      // das Panel zeigt den Screenshot-Hinweis (statt ewig „Mit der Maus über …").
      if (guideSearchTimeout) clearTimeout(guideSearchTimeout);
      guideSearchTimeout = setTimeout(finishMiss, GUIDE_HOVER_MAX_WAIT);
      guideAttachHover(h.el, step);
    };

    const finishMiss = () => {
      if (done) return;
      done = true;
      guideStopSearch();
      try {
        chrome.runtime.sendMessage({ type: "steply-guide-status", found: false, reason: lastReason });
      } catch (err) {
        /* egal */
      }
    };

    const tryResolve = () => {
      if (done) return true;
      let res = null;
      try {
        res = resolver(document, step.selector, RESOLVE_OPTS);
      } catch (err) {
        res = null;
      }
      if (res && res.el) {
        // Noch ohne Layout (0×0 — z. B. waehrend Hydration/PPR-Streaming versteckt)?
        // Dann NICHT andocken: scrollIntoView liefe ins Leere und die erste Reposition
        // meldete sofort „target-gone". Weiter suchen — der 250ms-Tick faengt auch
        // reine Layout-Aenderungen ohne DOM-Mutation (Hotfix 06.07.).
        let rr = null;
        try {
          rr = res.el.getBoundingClientRect();
        } catch (err) {
          rr = null;
        }
        if (!rr || (rr.width <= 0 && rr.height <= 0)) {
          lastReason = "target-hidden";
          if (hoverSel && !hoverShown) tryHover();
          return false;
        }
        done = true;
        guideStopSearch();
        // Aus der Hover-Phase: Ausloeser-Overlay abbauen, dann das echte Ziel markieren.
        if (hoverShown) guideCleanup();
        guideAttach(res.el, step);
        return true;
      }
      if (res && res.reason) lastReason = res.reason;
      if (hoverSel && !hoverShown) tryHover();
      return false;
    };

    if (tryResolve()) return;

    // MutationObserver reagiert SOFORT auf neu gerenderten Inhalt; ein kurzer Zeit-Guard
    // (~60ms) buendelt Mutations-Stuerme, damit die Aufloesung nicht pro Knoten feuert.
    let obsPending = false;
    try {
      guideSearchObserver = new MutationObserver(() => {
        if (obsPending || done) return;
        obsPending = true;
        setTimeout(() => {
          obsPending = false;
          tryResolve();
        }, 60);
      });
      guideSearchObserver.observe(document.documentElement || document, {
        childList: true,
        subtree: true,
      });
    } catch (err) {
      guideSearchObserver = null;
    }
    // Fallback-Tick fuer Aenderungen, die keine DOM-Mutation ausloesen (spaetes Layout u. ae.).
    guideSearchTick = setInterval(tryResolve, 250);
    if (!hoverShown) guideSearchTimeout = setTimeout(finishMiss, MAX_WAIT);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "steply-guide-show") {
      guideNoteSignal();
      // all_frames (Welle 48): nur der zustaendige Frame zeigt den Schritt. Alle anderen raeumen
      // ein evtl. eigenes Overlay des VORIGEN Schritts ab (der lag z. B. im iframe) und schweigen.
      if (!stepIsForThisFrame(msg.step)) {
        guideCurrentStep = null;
        guideCleanup();
        return;
      }
      showGuideStep(msg.step);
      guideStartWatchdog();
      return;
    }
    if (msg.type === "steply-guide-ping") {
      // Lebenszeichen des Panels (Welle 33, Fix 2b): verlaengert den Selbstschutz-Zeitgeber.
      guideNoteSignal();
      return;
    }
    if (msg.type === "steply-guide-hide") {
      guideCurrentStep = null; // keine stille Wiederaufnahme nach explizitem Ende
      guideCleanup();
      return;
    }
  });

  // ============================================================================
  // AUTOMATIONEN-AUSFÜHRUNG (Welle 36b): Das Panel schickt pro Schritt
  // {type:"steply-exec-step", step:{selector, action, value?, index, total}, token}.
  // Wir lösen das Element via SteplyGuideResolve auf (5s, MutationObserver — Muster
  // showGuideStep), zeigen eine ANIMIERTE Maus (Koralle-Zeiger mit Schatten, gleitet vom
  // letzten Punkt/Bildschirmmitte zum Ziel in EXEC_CURSOR_TRAVEL_MS, verweilt kurz, dann
  // „Klick-Puls" beim Ausführen) + einen Rahmen ums Ziel, und FÜHREN dann die Aktion aus:
  //   click  → pointer/mouse-Gesten; Submit-Button im <form> via form.requestSubmit(el)
  //            (React-19-Form-Action-sicher), sonst el.click()
  //   fill   → React-sicherer value-Setter + input/change + blur (Wert NIE geloggt)
  //   select → Option per value ODER sichtbarem Text; nicht gefunden ⇒ Miss (kein Raten)
  //   toggle → Klick-Sequenz (Checkbox/Radio/Switch)
  // Antwort: {type:"steply-exec-result", token, ok:true} bzw. {ok:false, reason}.
  // SICHERHEIT: Bei ok:false wird NIEMALS geklickt — der Lauf pausiert im Panel.
  // „steply-exec-hide" räumt Cursor/Rahmen restlos ab; Ping/Watchdog (60s) wie die Führung.
  // Eigener Namespace + eigene IDs → keine Kollision mit der Führung.
  // ============================================================================
  const EXEC_OVERLAY_ID = "__steply-exec-frame";
  const EXEC_CURSOR_ID = "__steply-exec-cursor";
  const EXEC_GLOW = "0 0 0 3px rgba(239,106,78,0.5), 0 0 14px 3px rgba(239,106,78,0.32)";
  const EXEC_SIGNAL_MAX_IDLE = 60000;
  // Maus-Timing (Welle 37, Fix 3): Richard empfand die Cursor-Reise als zu hektisch. Die
  // Reise ist jetzt gemächlicher (weiterhin ease-out) und der Cursor VERWEILT kurz auf dem
  // Ziel, bevor die Aktion ausgelöst wird. Benannte Konstanten → künftiges Tuning ist trivial.
  const EXEC_CURSOR_TRAVEL_MS = 750; // Reisedauer des Cursors zum Ziel (vorher ~450 ms)
  const EXEC_CURSOR_DWELL_MS = 250; // Verweilpause auf dem Ziel VOR der Aktion (Klick-Puls danach)
  // Datei-Brücke (Welle 39): Deckel für im Speicher getragene Dateien (Weg 1). Darüber → Weg 2/3.
  const EXEC_FILE_CAP = 50 * 1024 * 1024;

  // Datei-Brücke: getragene Dateien, die das Panel für einen Upload-Schritt hierher überträgt.
  // { [fileId]: { name, mime, b64 } | { name, mime, parts:[], got, total } }. SICHERHEIT: leben
  // NUR während des Laufs, gehen NIE ins DOM/Netz und werden bei execCleanup restlos geleert.
  let execFiles = {};

  let execCursorEl = null; // persistente animierte Maus (überlebt Schritte)
  let execFrameEl = null; // Rahmen ums aktuelle Ziel
  let execLastPoint = null; // { x, y } — letzte Cursor-Position (Start der nächsten Animation)
  let execSearchObserver = null;
  let execSearchTick = null;
  let execSearchTimeout = null;
  let execLastSignalAt = 0;
  let execWatchdog = null;
  // Welle 48: laufende Nummer des aktuellen Schritts. Asynchrone Phasen (Hover-Menue oeffnen,
  // Ablage-Ziel suchen) pruefen sie nach jedem await — kam inzwischen ein neuer Schritt, ein
  // Hide oder gehoert der Schritt einem anderen Frame, brechen sie still ab (nie doppelt handeln).
  let execRunSeq = 0;

  function execWait(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }

  function execStopSearch() {
    if (execSearchObserver) {
      try {
        execSearchObserver.disconnect();
      } catch (err) {
        /* egal */
      }
      execSearchObserver = null;
    }
    if (execSearchTick) {
      clearInterval(execSearchTick);
      execSearchTick = null;
    }
    if (execSearchTimeout) {
      clearTimeout(execSearchTimeout);
      execSearchTimeout = null;
    }
  }

  function execStopWatchdog() {
    if (execWatchdog) {
      clearInterval(execWatchdog);
      execWatchdog = null;
    }
  }

  // Verwaiste Cursor/Rahmen früherer (per Reload verwaister) Script-Instanzen abräumen.
  function execRemoveStrays() {
    try {
      document.querySelectorAll('[id="' + EXEC_OVERLAY_ID + '"]').forEach((n) => {
        if (n !== execFrameEl) {
          try {
            n.remove();
          } catch (err) {
            /* egal */
          }
        }
      });
      document.querySelectorAll('[id="' + EXEC_CURSOR_ID + '"]').forEach((n) => {
        if (n !== execCursorEl) {
          try {
            n.remove();
          } catch (err) {
            /* egal */
          }
        }
      });
    } catch (err) {
      /* egal */
    }
  }

  function execRemoveFrame() {
    if (execFrameEl && execFrameEl.parentNode) {
      try {
        execFrameEl.parentNode.removeChild(execFrameEl);
      } catch (err) {
        /* egal */
      }
    }
    execFrameEl = null;
  }

  // Buehne nach ERLEDIGTEM Schritt selbst abraeumen (Hotfix 06.07., Richard): im
  // Halbautomatik-Modus liegt zwischen zwei Schritten beliebig viel Zeit — Marker und
  // Maus des alten Schritts sollen dann nicht stehen bleiben. Kurze Verzoegerung, damit
  // der Klick-Puls noch sichtbar ist; startet vorher ein neuer Schritt, wird der Timer
  // storniert (execRunStep) und die Buehne ohnehin neu aufgebaut. execLastPoint bleibt
  // erhalten, damit die Maus beim naechsten Schritt von der alten Position weiterfaehrt.
  let execTidyTimer = null;
  function execScheduleTidy() {
    if (execTidyTimer) clearTimeout(execTidyTimer);
    execTidyTimer = setTimeout(() => {
      execTidyTimer = null;
      execRemoveFrame();
      if (execCursorEl && execCursorEl.parentNode) {
        try {
          execCursorEl.parentNode.removeChild(execCursorEl);
        } catch (err) {
          /* egal */
        }
      }
      execCursorEl = null;
    }, 650);
  }

  function execCleanup() {
    execRunSeq++; // laufende Hover-/Zieh-Phase abbrechen
    execStopSearch();
    execStopWatchdog();
    if (execTidyTimer) {
      clearTimeout(execTidyTimer);
      execTidyTimer = null;
    }
    execRemoveFrame();
    if (execCursorEl && execCursorEl.parentNode) {
      try {
        execCursorEl.parentNode.removeChild(execCursorEl);
      } catch (err) {
        /* egal */
      }
    }
    execCursorEl = null;
    execLastPoint = null;
    // Datei-Brücke (Welle 39): getragene Datei-Bytes bei JEDEM Lauf-Ende restlos vergessen.
    execFiles = {};
    execRemoveStrays();
  }

  // ── Datei-Brücke (Welle 39): base64 ⇄ Bytes + Content-Disposition-Dateiname ──────────────
  function execB64ToBytes(b64) {
    const bin = atob(String(b64 || ""));
    const len = bin.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    return bytes;
  }
  function execAbToBase64(ab) {
    let bin = "";
    const bytes = new Uint8Array(ab);
    const chunk = 0x8000; // in Stücken, sonst sprengt String.fromCharCode.apply den Stack
    for (let i = 0; i < bytes.length; i += chunk) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
    }
    return btoa(bin);
  }
  function execFilenameFromCD(cd) {
    if (!cd) return "";
    let m = /filename\*=(?:UTF-8'')?([^;]+)/i.exec(cd);
    if (m) {
      try {
        return decodeURIComponent(m[1].replace(/["']/g, "").trim()).replace(/[\\/]+/g, "_");
      } catch (e) {
        /* fällt auf die einfache Variante zurück */
      }
    }
    m = /filename="?([^";]+)"?/i.exec(cd);
    return m ? m[1].trim().replace(/[\\/]+/g, "_") : "";
  }

  // Maus-Zeiger (Koralle, weißer Rand, weicher Schatten) — per createElementNS gebaut, damit
  // KEIN innerHTML/Trusted-Types-Problem auf strengen Seiten entsteht. Die Spitze liegt bei
  // (4,2) im SVG; der Container wird um (-4,-2) verschoben, damit sie auf dem Zielpunkt sitzt.
  function execEnsureCursor() {
    if (execCursorEl && execCursorEl.isConnected) return execCursorEl;
    const c = document.createElement("div");
    c.id = EXEC_CURSOR_ID;
    const s = c.style;
    s.position = "fixed";
    s.zIndex = "2147483647";
    s.pointerEvents = "none";
    s.left = "0";
    s.top = "0";
    s.width = "24px";
    s.height = "24px";
    s.transform = "translate(-4px, -2px)";
    s.filter = "drop-shadow(0 3px 5px rgba(0,0,0,0.35))";
    try {
      const NS = "http://www.w3.org/2000/svg";
      const svg = document.createElementNS(NS, "svg");
      svg.setAttribute("width", "24");
      svg.setAttribute("height", "24");
      svg.setAttribute("viewBox", "0 0 24 24");
      const path = document.createElementNS(NS, "path");
      path.setAttribute("d", "M4 2 L4 20 L9 15 L12.5 22 L15.5 20.8 L12 14 L19 14 Z");
      path.setAttribute("fill", "#ef6a4e");
      path.setAttribute("stroke", "#ffffff");
      path.setAttribute("stroke-width", "1.4");
      path.setAttribute("stroke-linejoin", "round");
      svg.appendChild(path);
      c.appendChild(svg);
    } catch (err) {
      // Ohne SVG: ein einfacher Koralle-Punkt reicht als sichtbare Maus.
      c.style.background = "#ef6a4e";
      c.style.borderRadius = "50%";
      c.style.border = "2px solid #fff";
    }
    (document.documentElement || document.body).appendChild(c);
    execCursorEl = c;
    if (!execLastPoint) {
      execLastPoint = { x: (window.innerWidth || 0) / 2, y: (window.innerHeight || 0) / 2 };
    }
    execPlaceCursor(execLastPoint.x, execLastPoint.y);
    return c;
  }

  function execPlaceCursor(x, y) {
    if (!execCursorEl) return;
    execCursorEl.style.left = x + "px";
    execCursorEl.style.top = y + "px";
    execLastPoint = { x: x, y: y };
  }

  function execRectOf(el) {
    const vw = window.innerWidth || 0;
    const vh = window.innerHeight || 0;
    let r = null;
    try {
      r = el.getBoundingClientRect();
    } catch (err) {
      r = null;
    }
    if (!r) return { left: vw / 2, top: vh / 2, width: 0, height: 0, cx: vw / 2, cy: vh / 2 };
    return {
      left: r.left,
      top: r.top,
      width: r.width,
      height: r.height,
      cx: r.left + r.width / 2,
      cy: r.top + r.height / 2,
    };
  }

  // Maus in EXEC_CURSOR_TRAVEL_MS ease-out zum Ziel gleiten lassen. Promise löst nach dem Ankommen.
  function execAnimateCursorTo(x, y) {
    execEnsureCursor();
    const from = execLastPoint || { x: (window.innerWidth || 0) / 2, y: (window.innerHeight || 0) / 2 };
    return new Promise((resolve) => {
      let settled = false;
      const finish = () => {
        if (settled) return;
        settled = true;
        execPlaceCursor(x, y);
        resolve();
      };
      try {
        const anim = execCursorEl.animate(
          [
            { left: from.x + "px", top: from.y + "px" },
            { left: x + "px", top: y + "px" },
          ],
          { duration: EXEC_CURSOR_TRAVEL_MS, easing: "cubic-bezier(0.22,1,0.36,1)", fill: "forwards" }
        );
        anim.onfinish = finish;
        anim.oncancel = finish;
        // Sicherheitsnetz, falls onfinish nie feuert (Tab im Hintergrund u. ä.): Reisedauer + Puffer.
        setTimeout(finish, EXEC_CURSOR_TRAVEL_MS + 170);
      } catch (err) {
        finish();
      }
    });
  }

  // Kurzer „Klick-Puls": Koralle-Ring, der aufploppt und verblasst.
  function execClickPulse(x, y) {
    try {
      const ring = document.createElement("div");
      const s = ring.style;
      s.position = "fixed";
      s.zIndex = "2147483647";
      s.pointerEvents = "none";
      s.left = x - 14 + "px";
      s.top = y - 14 + "px";
      s.width = "28px";
      s.height = "28px";
      s.borderRadius = "50%";
      s.border = "3px solid #ef6a4e";
      s.boxShadow = "0 0 0 3px rgba(239,106,78,0.25)";
      (document.documentElement || document.body).appendChild(ring);
      ring
        .animate(
          [
            { opacity: 0.9, transform: "scale(0.5)" },
            { opacity: 0.7, transform: "scale(1.0)", offset: 0.5 },
            { opacity: 0, transform: "scale(1.7)" },
          ],
          { duration: 500, easing: "ease-out" }
        ).onfinish = () => ring.remove();
    } catch (err) {
      /* Puls ist optional */
    }
  }

  function execShowFrame(rect) {
    execRemoveFrame();
    const f = document.createElement("div");
    f.id = EXEC_OVERLAY_ID;
    const s = f.style;
    s.position = "fixed";
    s.zIndex = "2147483646";
    s.pointerEvents = "none";
    s.boxSizing = "border-box";
    s.border = "3px solid #ef6a4e";
    s.borderRadius = "10px";
    s.boxShadow = EXEC_GLOW;
    const pad = 4;
    s.left = rect.left - pad + "px";
    s.top = rect.top - pad + "px";
    s.width = rect.width + pad * 2 + "px";
    s.height = rect.height + pad * 2 + "px";
    (document.documentElement || document.body).appendChild(f);
    execFrameEl = f;
  }

  // submitted (Welle 38, additiv): true, wenn die Aktion eine Formular-Submission war
  // (requestSubmit auf einem <form>). Das Panel verifiziert danach, ob die Übermittlung
  // wirklich durchkam (URL-Wechsel) oder die Seite nur neu lud (submit-bounced).
  function execSendResult(token, ok, reason, submitted) {
    try {
      chrome.runtime.sendMessage({
        type: "steply-exec-result",
        token: token,
        ok: !!ok,
        reason: ok ? "" : reason || "unbekannt",
        submitted: !!submitted,
      });
    } catch (err) {
      /* Panel evtl. geschlossen — egal */
    }
  }

  // Realistische Zeiger-/Maus-Gesten (pointerdown, mousedown, pointerup, mouseup). Der
  // eigentliche Klick kommt danach über el.click() — GENAU EINMAL. (Kein zusätzlich
  // dispatchtes click-Event, sonst würde eine Checkbox/ein Switch doppelt umgeschaltet.)
  function execPointerGesture(el) {
    let cx = 0;
    let cy = 0;
    try {
      const r = el.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
    } catch (err) {
      /* egal */
    }
    const base = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0 };
    const fire = (type, usePointer) => {
      try {
        if (usePointer && typeof PointerEvent === "function") {
          el.dispatchEvent(new PointerEvent(type, base));
        } else {
          el.dispatchEvent(new MouseEvent(type, base));
        }
      } catch (err) {
        try {
          el.dispatchEvent(new MouseEvent(type, base));
        } catch (e) {
          /* egal */
        }
      }
    };
    fire("pointerdown", true);
    fire("mousedown", false);
    fire("pointerup", true);
    fire("mouseup", false);
  }

  // Ist `el` ein SUBMIT-Button innerhalb eines <form>? Dann liefern wir das Formular zurück,
  // damit der Klick über die standardkonforme Submission (form.requestSubmit(el)) statt über
  // eine rohe click()-Sequenz läuft.
  //
  // WARUM (Welle 37, Fix 1 — echter Bug, per Playwright reproduziert): Auf React-19-Form-
  // Actions (`<form action={fn}>` + useActionState) füllte unsere Sequenz E-Mail + Passwort
  // und rief dann el.click() auf dem „Anmelden"-Button. Die Server-Action LIEF zwar (Cookie
  // gesetzt), aber die Seite blieb/„reloadete" auf /login statt zur App zu navigieren: der
  // synthetische Klick löst die native Formular-Submission aus, die React nicht als seine
  // eigene Action-Submission übernimmt → das clientseitige redirect() der Action greift nicht.
  // form.requestSubmit(el) fährt die Formular-Submission-Algorithmus GENAU EINMAL mit dem
  // Button als submitter — React behandelt das exakt wie einen echten Klick (inkl. Navigation).
  function execFormForSubmit(el) {
    try {
      // Nur <button>/<input>/<select>/<textarea> haben eine .form-Property; sonst undefined.
      var form = el && el.form ? el.form : null;
      if (!form || typeof form.requestSubmit !== "function") return null;
      var tag = (el.tagName || "").toLowerCase();
      var type = (el.getAttribute && el.getAttribute("type") ? el.getAttribute("type") : "").toLowerCase();
      // Submit-Button: <button> ohne type ODER type=submit; <input type=submit|image>.
      var isSubmit =
        (tag === "button" && (type === "" || type === "submit")) ||
        (tag === "input" && (type === "submit" || type === "image"));
      return isSubmit ? form : null;
    } catch (err) {
      return null;
    }
  }

  function execClick(el) {
    try {
      execPointerGesture(el);
      var form = execFormForSubmit(el);
      if (form) {
        // Standardkonforme Submission mit dem Button als submitter (React-19-Form-Action-sicher).
        try {
          form.requestSubmit(el);
        } catch (err) {
          // requestSubmit(submitter) sehr selten nicht unterstützt → Fallback auf rohen Klick.
          el.click();
        }
        return { ok: true };
      }
      el.click();
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "click-error" };
    }
  }

  function execToggle(el) {
    try {
      execPointerGesture(el);
      el.click();
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "toggle-error" };
    }
  }

  // React-sicheres Befüllen: nativen value-Setter nutzen (React hört auf den echten Setter),
  // dann input + change dispatchen, dann blur. Der WERT wird NIE geloggt.
  // enter (Welle 48): statt blur Enter drücken wie ein Mensch — MIT Fokus im Feld (Google-Suche
  // reagiert nur mit Fokus); s. execEnterSubmit. submitted meldet eine Formular-Übermittlung.
  function execFill(el, value, enter) {
    const v = value == null ? "" : String(value);
    try {
      if (el.isContentEditable === true) {
        try {
          el.focus();
        } catch (e) {
          /* egal */
        }
        el.textContent = v;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        if (enter) return { ok: true, submitted: execEnterSubmit(el) };
        try {
          el.blur();
        } catch (e) {
          /* egal */
        }
        return { ok: true };
      }
      const tag = (el.tagName || "").toLowerCase();
      const proto =
        tag === "textarea"
          ? HTMLTextAreaElement.prototype
          : tag === "input"
            ? HTMLInputElement.prototype
            : null;
      if (!proto) return { ok: false, reason: "not-fillable" };
      try {
        el.focus();
      } catch (e) {
        /* egal */
      }
      const desc = Object.getOwnPropertyDescriptor(proto, "value");
      if (desc && desc.set) desc.set.call(el, v);
      else el.value = v;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      if (enter) return { ok: true, submitted: execEnterSubmit(el) };
      try {
        el.blur();
      } catch (e) {
        /* egal */
      }
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "fill-error" };
    }
  }

  // ── Welle 48: erweiterte Interaktion beim Abspielen ────────────────────────────────────
  function execFormOf(el) {
    try {
      const f = (el && el.form) || (el && el.closest ? el.closest("form") : null);
      return f && typeof f.requestSubmit === "function" ? f : null;
    } catch (err) {
      return null;
    }
  }

  // Soll das Panel die Übermittlung prüfen (submit-bounced-Netz, Welle 38)? Nur bei Formularen,
  // die eine Anmeldung/Aktion POSTEN (method=post) oder React-Form-Actions (action="javascript:…").
  // Eine GET-Suche landet legitim wieder auf demselben Pfad (/search → /search) — kein „Bounce".
  function execFormNeedsVerify(form) {
    if (!form) return false;
    try {
      const method = String(form.getAttribute("method") || form.method || "").toLowerCase();
      const action = String(form.getAttribute("action") || "");
      return method === "post" || /^javascript:/i.test(action);
    } catch (err) {
      return false;
    }
  }

  // Enter wie ein Mensch: keydown → (keypress, falls nicht abgefangen) → keyup, bubbles +
  // cancelable. Rückgabe true = die Seite hat das keydown NICHT abgefangen (defaultPrevented false).
  function execPressEnter(el) {
    const init = {
      key: "Enter",
      code: "Enter",
      keyCode: 13,
      which: 13,
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
    };
    const free = el.dispatchEvent(new KeyboardEvent("keydown", init));
    let pressFree = true;
    if (free) pressFree = el.dispatchEvent(new KeyboardEvent("keypress", Object.assign({ charCode: 13 }, init)));
    el.dispatchEvent(new KeyboardEvent("keyup", init));
    return free && pressFree;
  }

  // Eingabe mit Enter abschicken. Die Seite darf selbst abschicken (Google: keydown-Handler ruft
  // requestSubmit) — das erkennen wir am submit-Ereignis und schicken dann NICHT noch einmal ab.
  // Hat die Seite Enter nicht abgefangen und liegt das Feld in einem <form>, übernehmen wir die
  // implizite Übermittlung des Browsers: form.requestSubmit(). Rückgabe: soll geprüft werden?
  function execEnterSubmit(el) {
    const form = execFormOf(el);
    let pageSubmitted = false;
    const onSubmit = () => {
      pageSubmitted = true;
    };
    if (form) form.addEventListener("submit", onSubmit, true);
    let free = true;
    try {
      free = execPressEnter(el);
    } catch (err) {
      free = true;
    } finally {
      if (form) form.removeEventListener("submit", onSubmit, true);
    }
    let submitted = pageSubmitted;
    if (!submitted && free && form) {
      // Nur dort abschicken, wo ein ECHTES Enter es auch taete (HTML „implicit submission"):
      // Standard-Absendeknopf vorhanden, oder genau EIN Textfeld im Formular. Sonst (z. B.
      // Formular nur mit type=button-Speichern) haette der Mensch mit Enter nichts ausgeloest.
      const how = execImplicitSubmit(el, form);
      if (how) {
        try {
          if (how.button) form.requestSubmit(how.button);
          else form.requestSubmit();
          submitted = true;
        } catch (err) {
          submitted = false;
        }
      }
    }
    return submitted && execFormNeedsVerify(form);
  }

  const EXEC_IMPLICIT_TYPES =
    /^(text|search|url|tel|email|password|date|month|week|time|datetime-local|number)$/;
  // null = Enter schickt NICHT ab; {button} = ueber diesen Standardknopf; {} = ohne Knopf.
  function execImplicitSubmit(el, form) {
    if ((el.tagName || "").toLowerCase() !== "input") return null; // textarea/rich: nie
    try {
      const els = Array.from(form.elements || []);
      const btn = els.find((b) => {
        const tag = (b.tagName || "").toLowerCase();
        const type = ((b.getAttribute && b.getAttribute("type")) || "").toLowerCase();
        return (
          (tag === "button" && (type === "" || type === "submit")) ||
          (tag === "input" && (type === "submit" || type === "image"))
        );
      });
      if (btn) return btn.disabled ? null : { button: btn };
      const blocking = els.filter((f) => {
        if ((f.tagName || "").toLowerCase() !== "input") return false;
        const type = ((f.getAttribute && f.getAttribute("type")) || "text").toLowerCase();
        return EXEC_IMPLICIT_TYPES.test(type);
      });
      return blocking.length === 1 ? {} : null;
    } catch (err) {
      return null;
    }
  }

  function execCenter(el) {
    const r = execRectOf(el);
    return { x: r.cx, y: r.cy };
  }

  // Maus-/Zeiger-Ereignis am Punkt (PointerEvent, wo moeglich; sonst MouseEvent).
  function execMouse(el, type, x, y, extra) {
    const init = Object.assign(
      { bubbles: true, cancelable: true, composed: true, view: window, clientX: x, clientY: y, button: 0, buttons: 0 },
      extra || {}
    );
    const isPointer = type.indexOf("pointer") === 0;
    try {
      if (isPointer && typeof PointerEvent === "function") {
        return el.dispatchEvent(new PointerEvent(type, Object.assign({ pointerId: 1, pointerType: "mouse", isPrimary: true }, init)));
      }
      return el.dispatchEvent(new MouseEvent(type, init));
    } catch (err) {
      try {
        return el.dispatchEvent(new MouseEvent(type, init));
      } catch (e) {
        return true;
      }
    }
  }

  // Rechtsklick: Zeiger-Sequenz mit rechter Taste + contextmenu am Element-Mittelpunkt.
  function execContextClick(el) {
    try {
      const c = execCenter(el);
      execMouse(el, "pointerdown", c.x, c.y, { button: 2, buttons: 2 });
      execMouse(el, "mousedown", c.x, c.y, { button: 2, buttons: 2 });
      execMouse(el, "pointerup", c.x, c.y, { button: 2 });
      execMouse(el, "mouseup", c.x, c.y, { button: 2 });
      el.dispatchEvent(
        new MouseEvent("contextmenu", {
          bubbles: true,
          cancelable: true,
          composed: true,
          view: window,
          clientX: c.x,
          clientY: c.y,
          button: 2,
          buttons: 2,
        })
      );
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "contextmenu-error" };
    }
  }

  // Doppelklick: zwei vollstaendige Klicks (detail 1, 2) + dblclick (detail 2).
  function execDoubleClick(el) {
    try {
      const c = execCenter(el);
      for (let n = 1; n <= 2; n++) {
        execMouse(el, "pointerdown", c.x, c.y, { buttons: 1, detail: n });
        execMouse(el, "mousedown", c.x, c.y, { buttons: 1, detail: n });
        execMouse(el, "pointerup", c.x, c.y, { detail: n });
        execMouse(el, "mouseup", c.x, c.y, { detail: n });
        execMouse(el, "click", c.x, c.y, { detail: n });
      }
      execMouse(el, "dblclick", c.x, c.y, { detail: 2 });
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "dblclick-error" };
    }
  }

  // Tastenkuerzel: Ziel fokussieren (ohne Klick), dann keydown/keyup mit den Modifiern an das
  // fokussierte Element (sonst body) — dort, wo auch ein Mensch tippen wuerde.
  function execKeyPress(el, combo) {
    const k = parseKeyCombo(combo);
    if (!k) return { ok: false, reason: "key-invalid" };
    try {
      if (el && typeof el.focus === "function" && document.activeElement !== el) {
        el.focus({ preventScroll: true });
      }
    } catch (err) {
      /* nicht fokussierbar — dann eben aufs aktive Element */
    }
    const tgt = document.activeElement || document.body;
    const init = {
      key: k.key,
      code: k.code,
      keyCode: k.keyCode,
      which: k.keyCode,
      ctrlKey: k.ctrlKey,
      altKey: k.altKey,
      shiftKey: k.shiftKey,
      metaKey: k.metaKey,
      bubbles: true,
      cancelable: true,
      composed: true,
      view: window,
    };
    try {
      tgt.dispatchEvent(new KeyboardEvent("keydown", init));
      tgt.dispatchEvent(new KeyboardEvent("keyup", init));
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "key-error" };
    }
  }

  // Ziehen (HTML5-DnD + Zeiger-Sequenz): vom Element zum Ablage-Ziel, die sichtbare Maus reist mit.
  async function execDrag(src, dst, seq) {
    const a = execCenter(src);
    let dt = null;
    try {
      dt = new DataTransfer();
    } catch (err) {
      dt = null;
    }
    const drag = (el, type, x, y) => {
      let ev;
      try {
        ev = new DragEvent(type, {
          bubbles: true,
          cancelable: true,
          composed: true,
          clientX: x,
          clientY: y,
          dataTransfer: dt,
        });
      } catch (err) {
        ev = new Event(type, { bubbles: true, cancelable: true });
        try {
          Object.defineProperty(ev, "dataTransfer", { value: dt });
        } catch (e) {
          /* egal */
        }
      }
      return el.dispatchEvent(ev);
    };
    execMouse(src, "pointerover", a.x, a.y);
    execMouse(src, "pointerdown", a.x, a.y, { buttons: 1 });
    execMouse(src, "mousedown", a.x, a.y, { buttons: 1 });
    drag(src, "dragstart", a.x, a.y);
    execMouse(src, "pointermove", a.x + 6, a.y + 6, { buttons: 1 });
    execMouse(src, "mousemove", a.x + 6, a.y + 6, { buttons: 1 });
    drag(src, "drag", a.x + 6, a.y + 6);
    // Ziel erst JETZT messen (die Seite kann beim Aufnehmen umbauen) und die Maus hinfahren.
    let b = execCenter(dst);
    await execAnimateCursorTo(b.x, b.y);
    if (seq !== execRunSeq) return { ok: false, reason: "aborted" };
    b = execCenter(dst);
    execMouse(dst, "pointermove", b.x, b.y, { buttons: 1 });
    execMouse(dst, "mousemove", b.x, b.y, { buttons: 1 });
    execMouse(dst, "pointerover", b.x, b.y, { buttons: 1 });
    execMouse(dst, "mouseover", b.x, b.y, { buttons: 1 });
    drag(dst, "dragenter", b.x, b.y);
    drag(dst, "dragover", b.x, b.y);
    drag(dst, "drop", b.x, b.y);
    drag(src, "dragend", b.x, b.y);
    execMouse(dst, "pointerup", b.x, b.y);
    execMouse(dst, "mouseup", b.x, b.y);
    return { ok: true };
  }

  // Hover: die Ereignisse, mit denen Seiten Menues oeffnen (pointerover/mouseover bubbeln —
  // React hoert darauf; mouseenter/pointerenter direkt am Element; dazu eine Bewegung).
  function execHoverEvents(el) {
    const c = execCenter(el);
    execMouse(el, "pointerover", c.x, c.y);
    execMouse(el, "pointerenter", c.x, c.y, { bubbles: false });
    execMouse(el, "mouseover", c.x, c.y);
    execMouse(el, "mouseenter", c.x, c.y, { bubbles: false });
    execMouse(el, "pointermove", c.x, c.y);
    execMouse(el, "mousemove", c.x, c.y);
  }

  // Element per Selektor aufloesen und bis maxMs warten, bis es SICHTBAR ist (100-ms-Takt).
  // null = nicht (rechtzeitig) sichtbar oder der Schritt wurde abgeloest (seq).
  async function execWaitVisible(sel, maxMs, seq) {
    const resolver =
      (globalThis.SteplyGuideResolve && globalThis.SteplyGuideResolve.resolveSelector) || null;
    if (!resolver || !sel) return null;
    const t0 = Date.now();
    for (;;) {
      if (seq !== execRunSeq) return null;
      let res = null;
      try {
        res = resolver(document, sel, RESOLVE_OPTS);
      } catch (err) {
        res = null;
      }
      if (res && res.el && resolveElIsVisible(res.el)) return res.el;
      if (Date.now() - t0 >= maxMs) return null;
      await execWait(100);
    }
  }

  // Hover-Schritt: erst den Ausloeser aufloesen, Maus hinfahren, Hover-Ereignisse senden, dann
  // bis 1,5 s warten, bis das Ziel sichtbar wird. Klappt es nicht → ehrlicher Miss (nie raten).
  async function execRunHover(step, token, seq) {
    const it = interactionOf(step) || {};
    // Menue schon offen (Ziel sichtbar)? Dann direkt handeln.
    let target = await execWaitVisible(step.selector, 0, seq);
    if (seq !== execRunSeq) return;
    if (!target) {
      const trigger = await execWaitVisible(it.hover, 5000, seq);
      if (seq !== execRunSeq) return;
      if (!trigger) {
        execSendResult(token, false, "hover-not-found");
        return;
      }
      execEnsureCursor();
      try {
        trigger.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
      } catch (err) {
        /* egal */
      }
      await execWait(180);
      if (seq !== execRunSeq) return;
      const tr = execRectOf(trigger);
      execShowFrame(tr);
      await execAnimateCursorTo(tr.cx, tr.cy);
      if (seq !== execRunSeq) return;
      execHoverEvents(trigger);
      target = await execWaitVisible(step.selector, 1500, seq);
      if (seq !== execRunSeq) return;
      if (!target) {
        execSendResult(token, false, "hover-menu-closed");
        execScheduleTidy();
        return;
      }
    }
    execPerform(target, step, token, seq);
  }

  // Option per value ODER sichtbarem Text wählen (beides versuchen). Nicht gefunden ⇒ Miss
  // (kein Raten). Nur natives <select>.
  function execSelect(el, value) {
    if ((el.tagName || "").toLowerCase() !== "select") return { ok: false, reason: "not-a-select" };
    const want = value == null ? "" : String(value);
    const wantLc = want.trim().toLowerCase();
    const opts = el.options || [];
    let match = null;
    for (let i = 0; i < opts.length; i++) {
      if (opts[i].value === want) {
        match = opts[i];
        break;
      }
    }
    if (!match) {
      for (let j = 0; j < opts.length; j++) {
        const t = (opts[j].textContent || "").trim().toLowerCase();
        if (t && t === wantLc) {
          match = opts[j];
          break;
        }
      }
    }
    if (!match) return { ok: false, reason: "option-not-found" };
    try {
      const desc = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, "value");
      if (desc && desc.set) desc.set.call(el, match.value);
      else el.value = match.value;
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    } catch (err) {
      return { ok: false, reason: "select-error" };
    }
  }

  function execDoAction(el, step) {
    const action = step && step.action;
    const it = interactionOf(step) || {};
    if (action === "fill") return execFill(el, step.value, it.enter === true);
    if (action === "select") return execSelect(el, step.value);
    if (action === "toggle") return execToggle(el);
    // Klick-Varianten (Welle 48). Ziehen laeuft asynchron in execPerform (Maus reist mit).
    if (it.variant === "right") return execContextClick(el);
    if (it.variant === "double") return execDoubleClick(el);
    if (it.variant === "key") return execKeyPress(el, it.key);
    return execClick(el); // Default: click
  }

  // Ziel gefunden → in Sicht scrollen, Maus hinführen, Puls, Aktion, Ergebnis melden.
  // Vor einem Formular-Submit auf React-Seiten warten, bis die Hydration durch ist
  // (Hotfix 06.07. abends, Vercel-KALTSTART schlug jede feste Pause): Formular per
  // data-Attribut markieren (Attribute sehen beide Welten), dann via background eine
  // MAIN-World-Sonde pollen. „Kein React" -> sofort weiter (native Submission ist dort
  // korrekt). Obergrenze 8s -> danach Status quo (nicht ewig blockieren).
  async function execWaitHydration(formEl) {
    // Deckel 12s statt 8s (Welle 38): ein echter Kaltstart hydratisiert messbar langsamer
    // (gemessen 9,6 s bei 16x- und 14,1 s bei 20x-CPU-Drossel) — 8 s fiel VOR der Hydration
    // offen in einen nativen Submit (Voll-Reload) durch. 12 s + der Vorlauf (Scroll/Cursor
    // ~1,2 s) bleibt unter dem Panel-EXEC_STEP_TIMEOUT (20 s).
    const MAX = 12000;
    const TICK = 250;
    try {
      formEl.setAttribute("data-steply-hydration-probe", "1");
    } catch (err) {
      return;
    }
    // Geteiltes DOM-Signal: ist das ÜBERHAUPT eine React/Next-Seite? Die isolierte Welt sieht
    // Skript-Tags/Attribute — `script[src*="/_next/"]` steht ~50 ms nach Dokumentstart, lange
    // vor der Hydration; `[data-reactroot]` deckt Nicht-Next-React ab. Damit fällt die Sonde
    // NICHT offen in einen nativen Submit durch, wenn (a) die MAIN-World-Sonde kurz nicht
    // verfügbar ist (MV3-Service-Worker kalt nach Browser-Neustart → ok:false) oder (b) isReact
    // in einem frühen Fenster false meldet. Auf einer Nicht-Framework-Seite bleibt das alte
    // „nicht blockieren"-Verhalten (dort ist die native Submission korrekt).
    let looksFramework = false;
    try {
      looksFramework = !!document.querySelector('script[src*="/_next/"], [data-reactroot]');
    } catch (err) {
      looksFramework = false;
    }
    const t0 = Date.now();
    try {
      while (Date.now() - t0 < MAX) {
        let res = null;
        let probeFailed = false;
        try {
          res = await chrome.runtime.sendMessage({ type: "steply-probe-hydration" });
        } catch (err) {
          probeFailed = true;
        }
        if (probeFailed || !res || res.ok === false) {
          // Sonde nicht verfügbar. Auf einer erkennbaren Framework-Seite NICHT offen
          // durchfallen (sonst nativer Voll-Reload) — weiter pollen, bis sie sich meldet
          // oder der Deckel greift. Sonst (kein Framework) wie bisher sofort weiter.
          if (!looksFramework) return;
          await execWait(TICK);
          continue;
        }
        if (res.hydrated) return;
        // „kein React" nur glauben, wenn AUCH das geteilte DOM kein Framework zeigt.
        if (!res.isReact && !looksFramework) return;
        await execWait(TICK);
      }
    } finally {
      try {
        formEl.removeAttribute("data-steply-hydration-probe");
      } catch (err) {
        /* egal */
      }
    }
  }

  async function execPerform(el, step, token, seq) {
    const runSeq = typeof seq === "number" ? seq : execRunSeq;
    const it = interactionOf(step) || {};
    const variant = step && step.action === "click" ? it.variant : undefined;
    execEnsureCursor();
    try {
      el.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
    } catch (err) {
      try {
        el.scrollIntoView();
      } catch (e) {
        /* egal */
      }
    }
    await execWait(180); // kurzem smooth-Scroll Zeit geben, dann die reale Lage messen
    const rect = execRectOf(el);
    execShowFrame(rect);
    await execAnimateCursorTo(rect.cx, rect.cy);
    await execWait(EXEC_CURSOR_DWELL_MS); // kurz auf dem Ziel verweilen (Welle 37, Fix 3), dann handeln
    if (runSeq !== execRunSeq) return; // inzwischen abgeloest (neuer Schritt/Hide/anderer Frame)
    // Submit-Klicks erst NACH der React-Hydration ausloesen (sonst nativer Voll-Reload).
    let wasSubmit = false;
    if (step && step.action === "click" && !variant) {
      const form = execFormForSubmit(el);
      if (form) {
        wasSubmit = true;
        await execWaitHydration(form);
      }
    }
    // Eingabe + Enter (Welle 48): Enter schickt i. d. R. ein Formular ab → ebenfalls erst nach
    // der Hydration (sonst nativer Voll-Reload statt React-Action).
    if (step && step.action === "fill" && it.enter === true) {
      const form = execFormOf(el);
      if (form) await execWaitHydration(form);
    }
    if (runSeq !== execRunSeq) return;
    // Ziehen (Welle 48): Ablage-Ziel aufloesen (bis 3 s), dann die Zieh-Sequenz mit reisender Maus.
    if (variant === "drag") {
      const dropEl = await execWaitVisible(it.drop, 3000, runSeq);
      if (runSeq !== execRunSeq) return;
      if (!dropEl) {
        execSendResult(token, false, "drop-not-found");
        execScheduleTidy();
        return;
      }
      execClickPulse(rect.cx, rect.cy);
      let dres;
      try {
        dres = await execDrag(el, dropEl, runSeq);
      } catch (err) {
        dres = { ok: false, reason: "drag-error" };
      }
      if (runSeq !== execRunSeq) return;
      const b = execRectOf(dropEl);
      execClickPulse(b.cx, b.cy);
      execSendResult(token, dres && dres.ok, dres && dres.reason, false);
      execScheduleTidy();
      return;
    }
    execClickPulse(rect.cx, rect.cy); // „Klick-Puls" beim Ausführen
    let result;
    try {
      result = execDoAction(el, step);
    } catch (err) {
      result = { ok: false, reason: "action-error" };
    }
    if (result && result.submitted) wasSubmit = true; // Eingabe + Enter hat abgeschickt
    // WICHTIG bei navigierenden Klicks: das Ergebnis SYNCHRON nach der Aktion senden — die
    // Nachricht ist dann beim Browser, bevor eine Navigation die Seite abbaut (Muster wie
    // steply-guide-advance). submitted meldet dem Panel, dass es das Übermittlungs-Ergebnis
    // prüfen soll (Ehrlichkeits-Netz, Welle 38).
    execSendResult(token, result && result.ok, result && result.reason, wasSubmit);
    execScheduleTidy();
  }

  // ── Datei-Brücke (Welle 39): Upload ausführen ──────────────────────────────────────────
  // Ein sichtbares Anker-Element für Rahmen/Maus finden. Der Ziel-INPUT ist oft display:none
  // (Portale legen einen unsichtbaren file-input hinter ein gestyltes Label/Button) — dann
  // zielen Rahmen und Maus auf das sichtbare Label/Button, die Injektion trifft aber den INPUT.
  function execUploadAnchor(el) {
    const visible = (n) => {
      try {
        const r = n.getBoundingClientRect();
        return r && (r.width > 0 || r.height > 0) ? n : null;
      } catch (e) {
        return null;
      }
    };
    if (visible(el)) return el;
    try {
      if (el.labels && el.labels.length) {
        for (const l of el.labels) {
          const v = visible(l);
          if (v) return v;
        }
      }
    } catch (e) {
      /* egal */
    }
    try {
      if (el.id) {
        const l = document.querySelector('label[for="' + cssEscapeAttr(el.id) + '"]');
        if (l && visible(l)) return l;
      }
    } catch (e) {
      /* ungueltige id → egal */
    }
    try {
      const w = el.closest && el.closest("label");
      if (w && visible(w)) return w;
    } catch (e) {
      /* egal */
    }
    let p = el.parentElement;
    let guard = 0;
    while (p && guard < 4) {
      const v = visible(p);
      if (v) return v;
      p = p.parentElement;
      guard++;
    }
    return el; // nichts Sichtbares → execRectOf liefert dann die Bildschirmmitte
  }

  function execIsFileInput(el) {
    if (!el || (el.tagName || "").toLowerCase() !== "input") return false;
    const type = ((el.getAttribute && el.getAttribute("type")) || el.type || "").toLowerCase();
    return type === "file";
  }

  // Datei ins Ziel legen. file-input → File über DataTransfer setzen + input/change. Ist das
  // aufgelöste Ziel KEIN file-input (Drop-Zone), stattdessen dragenter/dragover/drop mit
  // dataTransfer.files dispatchen. Datei-Bytes bleiben lokal.
  function execInjectFile(el, f) {
    let bytes;
    try {
      bytes = execB64ToBytes(f.b64);
    } catch (e) {
      return { ok: false, reason: "decode-error" };
    }
    let file;
    try {
      file = new File([bytes], f.name || "datei", { type: f.mime || "application/octet-stream" });
    } catch (e) {
      return { ok: false, reason: "file-unsupported" };
    }
    let dt;
    try {
      dt = new DataTransfer();
      dt.items.add(file);
    } catch (e) {
      return { ok: false, reason: "datatransfer-unsupported" };
    }
    if (execIsFileInput(el)) {
      try {
        el.files = dt.files;
      } catch (e) {
        return { ok: false, reason: "files-readonly" };
      }
      try {
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      } catch (e) {
        /* egal — files ist gesetzt */
      }
      return { ok: true };
    }
    // Drop-Zone: reale Drag-&-Drop-Gestensequenz mit den Datei-Daten.
    let cx = 0;
    let cy = 0;
    try {
      const r = el.getBoundingClientRect();
      cx = r.left + r.width / 2;
      cy = r.top + r.height / 2;
    } catch (e) {
      /* egal */
    }
    const mk = (type) => {
      try {
        return new DragEvent(type, {
          bubbles: true,
          cancelable: true,
          dataTransfer: dt,
          clientX: cx,
          clientY: cy,
        });
      } catch (e) {
        // DragEvent-Konstruktor ohne dataTransfer-Option → dataTransfer manuell anhängen.
        const ev = new Event(type, { bubbles: true, cancelable: true });
        try {
          Object.defineProperty(ev, "dataTransfer", { value: dt });
        } catch (e2) {
          /* egal */
        }
        return ev;
      }
    };
    try {
      el.dispatchEvent(mk("dragenter"));
      el.dispatchEvent(mk("dragover"));
      el.dispatchEvent(mk("drop"));
    } catch (e) {
      return { ok: false, reason: "drop-error" };
    }
    return { ok: true };
  }

  async function execPerformUpload(el, step, token, f) {
    execEnsureCursor();
    const anchor = execUploadAnchor(el);
    try {
      anchor.scrollIntoView({ block: "center", inline: "center", behavior: "smooth" });
    } catch (err) {
      try {
        anchor.scrollIntoView();
      } catch (e) {
        /* egal */
      }
    }
    await execWait(180);
    const rect = execRectOf(anchor);
    execShowFrame(rect);
    await execAnimateCursorTo(rect.cx, rect.cy);
    await execWait(EXEC_CURSOR_DWELL_MS);
    execClickPulse(rect.cx, rect.cy);
    let result;
    try {
      result = execInjectFile(el, f);
    } catch (err) {
      result = { ok: false, reason: "upload-error" };
    }
    execSendResult(token, result && result.ok, result && result.reason, false);
    execScheduleTidy();
  }

  // Einen Upload-Schritt bearbeiten: den (evtl. UNSICHTBAREN) Ziel-Input auflösen — hier gilt
  // der 0×0-Guard NICHT (versteckte file-inputs sind normal). Fehlt die getragene Datei
  // (Weg-3-Fall im Panel), ehrlicher Miss. NIEMALS raten.
  function execRunUpload(step, token) {
    const f = step && step.fileId != null ? execFiles[step.fileId] : null;
    if (!f || !f.b64) {
      execSendResult(token, false, "file-missing");
      return;
    }
    if (!step.selector) {
      execSendResult(token, false, "no-selector");
      return;
    }
    const resolver =
      (globalThis.SteplyGuideResolve && globalThis.SteplyGuideResolve.resolveSelector) || null;
    if (!resolver) {
      execSendResult(token, false, "no-resolver");
      return;
    }
    const MAX_WAIT = 5000;
    let lastReason = "timeout";
    let done = false;
    const finishMiss = () => {
      if (done) return;
      done = true;
      execStopSearch();
      execSendResult(token, false, lastReason);
    };
    const tryResolve = () => {
      if (done) return true;
      let res = null;
      try {
        res = resolver(document, step.selector, RESOLVE_OPTS);
      } catch (err) {
        res = null;
      }
      if (res && res.el) {
        done = true;
        execStopSearch();
        execPerformUpload(res.el, step, token, f); // KEIN 0×0-Guard: hidden file-input ist ok
        return true;
      }
      if (res && res.reason) lastReason = res.reason;
      return false;
    };
    if (tryResolve()) return;
    let obsPending = false;
    try {
      execSearchObserver = new MutationObserver(() => {
        if (obsPending || done) return;
        obsPending = true;
        setTimeout(() => {
          obsPending = false;
          tryResolve();
        }, 60);
      });
      execSearchObserver.observe(document.documentElement || document, {
        childList: true,
        subtree: true,
      });
    } catch (err) {
      execSearchObserver = null;
    }
    execSearchTick = setInterval(tryResolve, 250);
    execSearchTimeout = setTimeout(finishMiss, MAX_WAIT);
  }

  // Einen Ausführ-Schritt bearbeiten: Element auflösen (bis 5s, MutationObserver + Tick),
  // sonst Miss + Grund melden. NIEMALS bei Miss klicken (Sicherheit).
  function execRunStep(step, token) {
    const seq = ++execRunSeq; // neuer Schritt → laufende Hover-/Zieh-Phasen des alten abbrechen
    execStopSearch();
    if (execTidyTimer) {
      clearTimeout(execTidyTimer); // neuer Schritt baut die Buehne selbst neu auf
      execTidyTimer = null;
    }
    execRemoveFrame(); // alten Rahmen weg; die Maus bleibt für die nächste Animation
    // Datei-Brücke (Welle 39): Upload-Schritte haben ihren eigenen Pfad (versteckter Input ok).
    if (step && step.action === "upload") {
      execRunUpload(step, token);
      return;
    }
    // Tastenkuerzel ohne fokussiertes Element (z. B. Strg+S auf der Seite): kein Ziel noetig —
    // die Tasten gehen ans aktive Element bzw. die Seite.
    const keyIt = interactionOf(step);
    if (step && !step.selector && keyIt && keyIt.variant === "key" && keyIt.key) {
      const r = execKeyPress(null, keyIt.key);
      execSendResult(token, r.ok, r.ok ? undefined : r.reason);
      return;
    }
    if (!step || !step.selector) {
      execSendResult(token, false, "no-selector");
      return;
    }
    const resolver =
      (globalThis.SteplyGuideResolve && globalThis.SteplyGuideResolve.resolveSelector) || null;
    if (!resolver) {
      execSendResult(token, false, "no-resolver");
      return;
    }
    // Hover-Menue (Welle 48): erst den Ausloeser „ueberfahren", dann das Ziel (eigener Pfad).
    const hit = interactionOf(step);
    if (hit && hit.hover) {
      execRunHover(step, token, seq).catch(() => {
        if (seq === execRunSeq) execSendResult(token, false, "hover-error");
      });
      return;
    }
    const MAX_WAIT = 5000;
    let lastReason = "timeout";
    let done = false;

    const finishMiss = () => {
      if (done) return;
      done = true;
      execStopSearch();
      execSendResult(token, false, lastReason);
    };

    const tryResolve = () => {
      if (done) return true;
      let res = null;
      try {
        res = resolver(document, step.selector, RESOLVE_OPTS);
      } catch (err) {
        res = null;
      }
      if (res && res.el) {
        // Noch ohne Layout (0×0 — Hydration/PPR)? Nicht andocken, weiter suchen.
        let rr = null;
        try {
          rr = res.el.getBoundingClientRect();
        } catch (err) {
          rr = null;
        }
        if (!rr || (rr.width <= 0 && rr.height <= 0)) {
          lastReason = "target-hidden";
          return false;
        }
        done = true;
        execStopSearch();
        execPerform(res.el, step, token, seq);
        return true;
      }
      if (res && res.reason) lastReason = res.reason;
      return false;
    };

    if (tryResolve()) return;

    let obsPending = false;
    try {
      execSearchObserver = new MutationObserver(() => {
        if (obsPending || done) return;
        obsPending = true;
        setTimeout(() => {
          obsPending = false;
          tryResolve();
        }, 60);
      });
      execSearchObserver.observe(document.documentElement || document, {
        childList: true,
        subtree: true,
      });
    } catch (err) {
      execSearchObserver = null;
    }
    execSearchTick = setInterval(tryResolve, 250);
    execSearchTimeout = setTimeout(finishMiss, MAX_WAIT);
  }

  function execNoteSignal() {
    execLastSignalAt = Date.now();
  }

  // Welle 48: dieser Frame ist fuer den aktuellen Schritt NICHT zustaendig. Wie execCleanup, aber
  // OHNE die getragenen Dateien zu vergessen (die braucht das Hauptfenster evtl. spaeter noch).
  function execYield() {
    execRunSeq++;
    execStopSearch();
    if (execTidyTimer) {
      clearTimeout(execTidyTimer);
      execTidyTimer = null;
    }
    execRemoveFrame();
    if (execCursorEl && execCursorEl.parentNode) {
      try {
        execCursorEl.parentNode.removeChild(execCursorEl);
      } catch (err) {
        /* egal */
      }
    }
    execCursorEl = null;
  }

  function execStartWatchdog() {
    if (execWatchdog) return;
    execWatchdog = setInterval(() => {
      if (!execCursorEl && !execFrameEl) {
        execStopWatchdog();
        return;
      }
      if (Date.now() - execLastSignalAt > EXEC_SIGNAL_MAX_IDLE) {
        // >60s kein Schritt/Ping → Panel vermutlich hart weg, selbst abräumen.
        execCleanup();
      }
    }, 10000);
  }

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;
    if (msg.type === "steply-exec-step") {
      execNoteSignal();
      // all_frames (Welle 48): genau EIN Frame fuehrt aus (s. stepIsForThisFrame) — sonst kaemen
      // mehrere steply-exec-result zurueck. Nicht zustaendig → eigene Buehne des vorigen
      // Schritts abraeumen (Maus/Rahmen), laufende Phasen abbrechen, schweigen.
      if (!stepIsForThisFrame(msg.step)) {
        execYield();
        return;
      }
      execRunStep(msg.step, msg.token);
      execStartWatchdog();
      return;
    }
    if (msg.type === "steply-exec-ping") {
      execNoteSignal();
      return;
    }
    if (msg.type === "steply-exec-hide") {
      execCleanup();
      return;
    }
  });

  // ── Datei-Brücke (Welle 39): Refetch (Weg 1) + Datei-Transport ans Content-Script ────────
  // Eigener Listener MIT sendResponse (async). SICHERHEIT: Datei-Bytes bleiben lokal — dieser
  // Refetch läuft im ORIGIN der Quellseite (credentials:'include'), damit kurzlebige Session-
  // Cookies greifen; das Ergebnis geht NUR zurück ins Panel (Extension-Speicher), nie an Steply.
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg) return false;
    // all_frames (Welle 48): Antworten (refetch, file-*, has-password, eval-condition) gibt NUR
    // das Hauptfenster. iframes schweigen ohne sendResponse → Chrome nimmt die Antwort von oben.
    // Ausnahme: eine Bedingung eines iframe-Schritts (msg.frame) beantwortet NUR dieser Frame.
    if (msg.type === "steply-eval-condition" && msg.frame) {
      if (!stepIsForThisFrame({ interaction: { frame: msg.frame } })) return false;
    } else if (!IS_TOP) return false;
    if (msg.type === "steply-exec-refetch") {
      (async () => {
        try {
          const resp = await fetch(msg.url, { credentials: "include" });
          if (!resp.ok) {
            sendResponse({ ok: false, reason: "http-" + resp.status });
            return;
          }
          const buf = await resp.arrayBuffer();
          if (buf.byteLength > EXEC_FILE_CAP) {
            // Deckel: zu groß für den Speicher-Weg → Panel entscheidet Weg 2/3.
            sendResponse({ ok: false, reason: "too-large", size: buf.byteLength });
            return;
          }
          sendResponse({
            ok: true,
            b64: execAbToBase64(buf),
            size: buf.byteLength,
            mime: resp.headers.get("content-type") || "",
            name: execFilenameFromCD(resp.headers.get("content-disposition") || ""),
          });
        } catch (e) {
          sendResponse({ ok: false, reason: "fetch-error" });
        }
      })();
      return true; // Antwort kommt asynchron
    }
    if (msg.type === "steply-exec-file") {
      // Kleine Datei: ganze base64 in EINER Nachricht.
      execFiles[msg.fileId] = { name: msg.name, mime: msg.mime, b64: msg.b64 };
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "steply-exec-file-begin") {
      // Große Datei (>8 MB base64): Chunk-Protokoll — Teile sammeln, dann zusammensetzen.
      execFiles[msg.fileId] = {
        name: msg.name,
        mime: msg.mime,
        parts: new Array(msg.total || 0),
        got: 0,
        total: msg.total || 0,
      };
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "steply-exec-file-chunk") {
      const f = execFiles[msg.fileId];
      if (f && Array.isArray(f.parts)) {
        if (f.parts[msg.seq] === undefined) f.got++;
        f.parts[msg.seq] = msg.b64;
        if (f.got >= f.total) f.b64 = f.parts.join("");
      }
      sendResponse({ ok: true, got: f ? f.got : 0, complete: !!(f && f.b64) });
      return true;
    }
    if (msg.type === "steply-exec-file-clear") {
      execFiles = {};
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "steply-exec-has-password") {
      // Zustands-Intelligenz (Welle 40): Passwortfeld-Probe für die Anmelde-Wache. Die isolierte
      // Welt reicht — input[type=password] ist ein reines DOM-Merkmal. SICHERHEIT: Wir LESEN nur,
      // ob ein solches Feld existiert; wir tippen NIE etwas hinein und lesen keine Werte.
      let has = false;
      try {
        has = !!document.querySelector('input[type="password"]');
      } catch (e) {
        has = false;
      }
      sendResponse({ ok: true, hasPassword: has });
      return true;
    }
    if (msg.type === "steply-eval-condition") {
      // Bedingte Schritte (Welle 42): Element-Bedingung im ZIEL-TAB auswerten. Antwort
      // { ok, met } mit met = ROHES „gefunden UND sichtbar" (getBoundingClientRect > 0) — OHNE
      // negate (das wendet AUSSCHLIESSLICH der Aufrufer via SteplyExecPlan.shouldRunStep an, EINE
      // dokumentierte Stelle). URL-Bedingungen kennt der Lauf selbst (Tab-URL) → hier nie met.
      // SICHERHEIT: reine Momentaufnahme — wir LESEN nur, ob das Element da/sichtbar ist; kein
      // Klick, kein Wert. ~300 ms Gnadenfrist, weil eine SPA das Banner minimal verzögert rendert.
      (async () => {
        const cond = msg.cond;
        if (!cond || cond.kind !== "element" || !cond.selector) {
          sendResponse({ ok: true, met: false });
          return;
        }
        const R = globalThis.SteplyGuideResolve;
        const check = () => {
          if (!R || typeof R.resolveSelector !== "function") return false;
          let res;
          try {
            // Welle 45: sichtbare Kandidaten bevorzugen (kein Haften an unsichtbaren Duplikaten).
            res = R.resolveSelector(document, cond.selector, RESOLVE_OPTS);
          } catch (e) {
            return false;
          }
          if (!res || !res.el) return false;
          // STRENG bei Bedingungen (Fix 07.07., Richards „Anmelden"-Fall): Eine Bedingung
          // fragt „ist GENAU DIESES Element da?" — dafür zählt NUR ein exakter Treffer
          // (confidence 'exact' = css+Text | 'text' = Rolle+exakter Text). Fuzzy (contains)
          // und 'healed' (volatile Text-Drift) sind fürs ANKLICKEN gedacht (Toleranz gut),
          // aber für eine Ja/Nein-Präsenzprüfung wären sie FALSCH-POSITIV: eingeloggt fehlt der
          // echte „Anmelden"-Knopf, ein ähnliches Element würde ihn sonst vortäuschen → der
          // Login-Schritt liefe fälschlich. Nur exakt/exakter-Text gilt als „vorhanden".
          if (res.confidence !== "exact" && res.confidence !== "text") return false;
          let r;
          try {
            r = res.el.getBoundingClientRect();
          } catch (e) {
            return false;
          }
          return !!(r && r.width > 0 && r.height > 0);
        };
        let met = check();
        if (!met) {
          await new Promise((r) => setTimeout(r, 300)); // Gnadenfrist für verzögert gerenderte Banner
          met = check();
        }
        sendResponse({ ok: true, met: met });
      })();
      return true; // Antwort kommt asynchron
    }
    return false;
  });

  // Beim Laden dieser Script-Instanz sofort Zombie-Overlays verwaister Vorgaenger entsorgen
  // (die Nachimpfung offener Tabs raeumt so nach jedem Extension-Reload automatisch auf).
  guideRemoveStrays();
  execRemoveStrays();

  // Aufnahmezustand aus einem storage-Wert uebernehmen.
  function applyRecState(rec) {
    if (rec && typeof rec.startedAt === "number") {
      startEpoch = rec.startedAt;
      mode = rec.mode === "guide" ? "guide" : "video";
      recording = true;
      // Neues Geheimnis = neue Sitzung → alten Geo-Kanal verwerfen.
      const nonce = typeof rec.nonce === "string" ? rec.nonce : "";
      if (nonce !== recNonce) {
        recNonce = nonce;
        geoPort = null;
        geoQueue = [];
      }
      // Ist beim Start schon ein Feld fokussiert (Google-Suchfeld, auch in Shadow-Roots),
      // gleich uebernehmen.
      const active = deepActiveElement();
      if (mode === "guide" && !focusedEditable && active) {
        adoptEditable(active, false);
      }
    } else {
      // Pause/Stopp (Welle 48): eine noch nicht abgeschlossene Eingabe (Feld nicht verlassen)
      // JETZT melden — das Panel nimmt nach dem Entfernen von rec noch kurz Schritte an.
      if (recording && mode === "guide") flushPendingInput();
      recording = false;
    }
  }

  // Beim Laden den aktuellen Zustand lesen (deckt frisch geladene Folge-Seiten ab).
  try {
    chrome.storage.local.get("rec", (res) => {
      if (chrome.runtime.lastError) return;
      applyRecState(res && res.rec);
    });
  } catch (err) {
    // storage nicht verfuegbar (sehr alte Chrome-Version) -> Script bleibt passiv.
  }

  // Auf Aenderungen des Aufnahmezustands lauschen (Start/Stopp waehrend die Seite offen ist).
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !changes.rec) return;
      applyRecState(changes.rec.newValue);
    });
  } catch (err) {
    // ignorieren
  }

  // Aufnahme-Ping (Welle 48a): Das Panel fragt in „Nimmt auf" beim Tab-Wechsel/Laden, ob hier
  // ein Content-Script lebt (sonst Hinweis „Auf dieser Seite kann Steply nicht aufnehmen").
  // Eigener Listener; antwortet NUR im Hauptfenster (iframes schweigen).
  try {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg || msg.type !== "steply-rec-ping") return false;
      if (!IS_TOP) return false;
      sendResponse({ ok: true });
      return false;
    });
  } catch (err) {
    // ignorieren
  }
})();
